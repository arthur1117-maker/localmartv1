package com.localmart.security;

import com.localmart.entity.User;
import com.localmart.enums.Role;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

@Service
public class JwtService {

    private final JwtProperties properties;
    private final SecretKey key;

    public JwtService(JwtProperties properties) {
        this.properties = properties;
        byte[] bytes = properties.getSecret().getBytes(StandardCharsets.UTF_8);
        if (bytes.length < 32) {
            bytes = (properties.getSecret() + "localmart-padding-key-256").getBytes(StandardCharsets.UTF_8);
        }
        this.key = Keys.hmacShaKeyFor(bytes.length >= 32 ? bytes : java.util.Arrays.copyOf(bytes, 32));
    }

    public String generateAccessToken(User user) {
        Instant now = Instant.now();
        return Jwts.builder()
                .id(UUID.randomUUID().toString())
                .subject(user.getId())
                .claim(SecurityConstants.TOKEN_TYPE_CLAIM, SecurityConstants.ACCESS_TOKEN_TYPE)
                .claim(SecurityConstants.EMAIL_CLAIM, user.getEmail())
                .claim(SecurityConstants.ROLE_CLAIM, user.getRole().name())
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plusMillis(properties.getAccessExpirationMs())))
                .signWith(key)
                .compact();
    }

    /** Opaque refresh token stored hashed in DB (not a JWT). */
    public String generateRefreshTokenValue() {
        return UUID.randomUUID() + "." + UUID.randomUUID();
    }

    public Claims parseAndValidateAccessToken(String token) {
        Claims claims = parse(token);
        String type = claims.get(SecurityConstants.TOKEN_TYPE_CLAIM, String.class);
        if (!SecurityConstants.ACCESS_TOKEN_TYPE.equals(type)) {
            throw new JwtException("Invalid token type");
        }
        return claims;
    }

    public Claims parse(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public String extractUserId(String token) {
        return parseAndValidateAccessToken(token).getSubject();
    }

    public Role extractRole(String token) {
        String role = parseAndValidateAccessToken(token).get(SecurityConstants.ROLE_CLAIM, String.class);
        return Role.valueOf(role);
    }

    public boolean isAccessTokenValid(String token) {
        try {
            parseAndValidateAccessToken(token);
            return true;
        } catch (ExpiredJwtException e) {
            return false;
        } catch (Exception e) {
            return false;
        }
    }
}
