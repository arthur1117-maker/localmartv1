package com.localmart.security.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.localmart.common.exception.ErrorResponse;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.Instant;

@Component
@RequiredArgsConstructor
public class SecurityJsonWriter {

    private final ObjectMapper objectMapper;

    public void write(
            HttpServletResponse response,
            int status,
            String error,
            String message
    ) throws IOException {
        response.setStatus(status);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        ErrorResponse body = new ErrorResponse(
                Instant.now(),
                status,
                error,
                message,
                null
        );
        objectMapper.writeValue(response.getOutputStream(), body);
    }
}
