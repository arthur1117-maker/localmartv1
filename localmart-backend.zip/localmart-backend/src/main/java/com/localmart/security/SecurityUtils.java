package com.localmart.security;

import com.localmart.common.exception.ApiException;
import com.localmart.entity.User;
import com.localmart.enums.Role;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

public final class SecurityUtils {

    private SecurityUtils() {}

    public static User currentUser() {
        return currentUserDetails().getUser();
    }

    public static LocalMartUserDetails currentUserDetails() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof LocalMartUserDetails details)) {
            throw ApiException.unauthorized("Authentication required");
        }
        return details;
    }

    public static User currentUserOrNull() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() instanceof LocalMartUserDetails details) {
            return details.getUser();
        }
        return null;
    }

    public static boolean isAuthenticated() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth != null && auth.isAuthenticated()
                && auth.getPrincipal() instanceof LocalMartUserDetails;
    }

    public static boolean hasRole(Role role) {
        return isAuthenticated() && currentUserDetails().hasRole(role);
    }

    public static void requireRole(Role role) {
        if (!hasRole(role)) {
            throw ApiException.forbidden("Required role: " + role.name());
        }
    }
}
