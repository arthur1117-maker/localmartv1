package com.localmart.security;

public final class SecurityConstants {

    private SecurityConstants() {}

    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final String BEARER_PREFIX = "Bearer ";
    public static final String TOKEN_TYPE_CLAIM = "typ";
    public static final String ACCESS_TOKEN_TYPE = "access";
    public static final String ROLE_CLAIM = "role";
    public static final String EMAIL_CLAIM = "email";

    public static final String[] PUBLIC_GET = {
            "/api/products/search",
            "/api/products/{id:\\d+}",
            "/api/categories",
            "/api/categories/**",
            "/api/reviews/product/**",
    };

    public static final String[] PUBLIC_AUTH = {
            "/api/auth/login",
            "/api/auth/register",
            "/api/auth/refresh",
            "/api/auth/logout",
    };

    public static final String[] PUBLIC_MISC = {
            "/h2-console/**",
            "/error",
    };
}
