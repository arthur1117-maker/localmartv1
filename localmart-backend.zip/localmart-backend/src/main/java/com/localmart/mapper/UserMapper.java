package com.localmart.mapper;

import com.localmart.dto.response.auth.AuthResponse;
import com.localmart.dto.response.user.AdminUserResponse;
import com.localmart.dto.response.user.UserResponse;
import com.localmart.entity.User;
import org.springframework.stereotype.Component;

import java.time.format.DateTimeFormatter;

@Component
public class UserMapper {

    private static final DateTimeFormatter JOINED_FMT = DateTimeFormatter.ofPattern("yyyy.MM.dd");

    public UserResponse toResponse(User user) {
        return new UserResponse(
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getRole().toApiValue(),
                user.getPhone(),
                user.getAimag(),
                user.isVerified(),
                user.isActive(),
                user.getAvatar()
        );
    }

    public AdminUserResponse toAdminResponse(User user) {
        return new AdminUserResponse(
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getRole().toApiValue(),
                user.getAimag() != null ? user.getAimag() : "",
                user.isVerified(),
                user.isActive(),
                JOINED_FMT.format(user.getCreatedAt().atZone(java.time.ZoneId.systemDefault())),
                user.getAvatar()
        );
    }

    public AuthResponse toAuthResponse(String accessToken, String refreshToken, User user) {
        return new AuthResponse(accessToken, refreshToken, toResponse(user));
    }
}
