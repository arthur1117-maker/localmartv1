package com.localmart.mapper;

import com.localmart.dto.response.review.ReviewResponse;
import com.localmart.entity.Review;
import org.springframework.stereotype.Component;

@Component
public class ReviewMapper {

    public ReviewResponse toResponse(Review review) {
        return new ReviewResponse(
                review.getId(),
                review.getRating(),
                review.getComment(),
                review.getBuyer().getName(),
                review.getCreatedAt()
        );
    }
}
