package com.localmart.mapper;

import com.localmart.dto.response.cart.CartLineResponse;
import com.localmart.dto.response.cart.CartResponse;
import com.localmart.dto.response.product.ProductResponse;
import com.localmart.entity.CartItem;
import com.localmart.enums.ProductApprovalStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
@RequiredArgsConstructor
public class CartMapper {

    private final ProductMapper productMapper;

    public CartResponse toResponse(List<CartItem> items) {
        List<CartLineResponse> lines = items.stream()
                .filter(ci -> ci.getProduct().isActive()
                        && ci.getProduct().getApprovalStatus() == ProductApprovalStatus.APPROVED)
                .map(ci -> new CartLineResponse(productMapper.toResponse(ci.getProduct()), ci.getQuantity()))
                .toList();
        BigDecimal total = lines.stream()
                .map(l -> l.product().price().multiply(BigDecimal.valueOf(l.quantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        int count = lines.stream().mapToInt(CartLineResponse::quantity).sum();
        return new CartResponse(lines, total, count);
    }
}
