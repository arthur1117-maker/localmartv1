package com.localmart.mapper;

import com.localmart.dto.request.product.ProductRequest;
import com.localmart.dto.response.product.ProductResponse;
import com.localmart.entity.Category;
import com.localmart.entity.Product;
import com.localmart.entity.ProductImage;
import com.localmart.entity.User;
import com.localmart.util.SlugUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ProductMapper {

    public ProductResponse toResponse(Product product) {
        List<String> urls = imageUrls(product);
        Category category = product.getCategory();
        return new ProductResponse(
                product.getId(),
                product.getName(),
                product.getPrice(),
                product.getUnit(),
                category != null ? category.getName() : "",
                category != null ? category.getId() : null,
                product.getAimag(),
                product.getEmoji(),
                product.getStory(),
                product.getRatingAvg(),
                product.getReviewCount(),
                product.getStock(),
                urls.size(),
                urls,
                product.isNew(),
                product.isOrganic(),
                product.isVerified(),
                product.isActive(),
                product.getApprovalStatus(),
                product.getSeller() != null ? product.getSeller().getName() : "",
                product.getSellerPhone() != null ? product.getSellerPhone()
                        : (product.getSeller() != null ? product.getSeller().getPhone() : null),
                product.getCreatedAt()
        );
    }

    public void applyRequest(Product product, Category category, User seller, ProductRequest request) {
        product.setName(request.name().trim());
        product.setPrice(request.price());
        product.setUnit(request.unit().trim());
        product.setCategory(category);
        product.setAimag(request.aimag().trim());
        if (request.emoji() != null && !request.emoji().isBlank()) {
            product.setEmoji(request.emoji().trim());
        }
        if (request.story() != null) {
            product.setStory(request.story().trim());
        }
        if (request.stock() != null) {
            product.setStock(request.stock());
        }
        if (request.isNew() != null) {
            product.setNew(request.isNew());
        }
        if (request.isOrganic() != null) {
            product.setOrganic(request.isOrganic());
        }
        product.setSellerPhone(request.sellerPhone() != null ? request.sellerPhone() : seller.getPhone());
        if (product.getSlug() == null || product.getSlug().isBlank()) {
            product.setSlug(SlugUtils.slugify(request.name()) + "-" + System.currentTimeMillis() % 100000);
        }
        syncImages(product, request.imageUrls());
    }

    public void syncImages(Product product, List<String> imageUrls) {
        if (imageUrls == null) {
            return;
        }
        product.getImages().clear();
        int order = 0;
        for (String url : imageUrls) {
            if (url == null || url.isBlank()) continue;
            product.getImages().add(ProductImage.builder()
                    .product(product)
                    .imageUrl(url.trim())
                    .sortOrder(order)
                    .primary(order == 0)
                    .build());
            order++;
        }
    }

    private List<String> imageUrls(Product product) {
        if (product.getImages() == null || product.getImages().isEmpty()) {
            return List.of();
        }
        return product.getImages().stream()
                .map(ProductImage::getImageUrl)
                .toList();
    }
}
