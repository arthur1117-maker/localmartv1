package com.localmart.mapper;

import com.localmart.dto.response.category.CategoryResponse;
import com.localmart.entity.Category;
import org.springframework.stereotype.Component;

@Component
public class CategoryMapper {

    public CategoryResponse toResponse(Category category) {
        return new CategoryResponse(
                category.getId(),
                category.getName(),
                category.getSlug(),
                category.getIcon(),
                category.getColorHex(),
                category.getBgHex(),
                category.getSortOrder()
        );
    }
}
