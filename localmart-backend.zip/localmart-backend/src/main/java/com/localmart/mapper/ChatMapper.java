package com.localmart.mapper;

import com.localmart.dto.response.chat.ChatMessageResponse;
import com.localmart.entity.ChatMessage;
import org.springframework.stereotype.Component;

@Component
public class ChatMapper {

    public ChatMessageResponse toResponse(ChatMessage message) {
        return new ChatMessageResponse(
                message.getId(),
                message.getSender().getId(),
                message.getSender().getName(),
                message.getReceiver().getId(),
                message.getContent(),
                message.isRead(),
                message.getSentAt(),
                message.getProduct() != null ? message.getProduct().getId() : null
        );
    }
}
