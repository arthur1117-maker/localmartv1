package com.localmart.mapper;

import com.localmart.dto.response.seller.DayRevenueResponse;
import com.localmart.dto.response.seller.SellerStatsResponse;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
public class SellerMapper {

    public SellerStatsResponse toStatsResponse(
            BigDecimal totalRevenue,
            long orderCount,
            long productCount,
            BigDecimal avgRating,
            List<DayRevenueResponse> weeklyRevenue
    ) {
        return new SellerStatsResponse(totalRevenue, orderCount, productCount, avgRating, weeklyRevenue);
    }

    public DayRevenueResponse toDayRevenue(String day, BigDecimal revenue, int pct) {
        return new DayRevenueResponse(day, revenue, pct);
    }
}
