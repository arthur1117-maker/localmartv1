package com.localmart.mapper;

import com.localmart.dto.response.order.OrderItemResponse;
import com.localmart.dto.response.order.OrderResponse;
import com.localmart.entity.Order;
import com.localmart.entity.OrderItem;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class OrderMapper {

    public OrderResponse toResponse(Order order) {
        List<OrderItemResponse> items = order.getItems().stream()
                .map(this::toItemResponse)
                .toList();
        return new OrderResponse(
                order.getId(),
                order.getOrderNumber(),
                order.getStatus().name(),
                order.getTotalAmount(),
                order.getDeliveryAddress(),
                order.getBuyerPhone(),
                order.getPaymentMethod(),
                order.getBuyer().getName(),
                order.getSeller().getName(),
                order.getCreatedAt(),
                items
        );
    }

    public OrderItemResponse toItemResponse(OrderItem item) {
        return new OrderItemResponse(
                item.getProductName(),
                item.getProductEmoji(),
                item.getQuantity(),
                item.getUnitPrice(),
                item.getSubtotal()
        );
    }
}
