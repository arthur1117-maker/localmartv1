package com.localmart.service.impl;

import com.localmart.common.exception.ApiException;
import com.localmart.dto.request.cart.CartItemRequest;
import com.localmart.dto.response.cart.CartResponse;
import com.localmart.entity.CartItem;
import com.localmart.entity.Product;
import com.localmart.entity.User;
import com.localmart.enums.ProductApprovalStatus;
import com.localmart.mapper.CartMapper;
import com.localmart.repository.CartItemRepository;
import com.localmart.repository.ProductRepository;
import com.localmart.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class CartServiceImpl implements CartService {

    private final CartItemRepository cartItemRepository;
    private final ProductRepository productRepository;
    private final CartMapper cartMapper;

    @Override
    public CartResponse getCart(User user) {
        return cartMapper.toResponse(cartItemRepository.findByUserOrderByUpdatedAtDesc(user));
    }

    @Override
    @Transactional
    public CartResponse addItem(User user, CartItemRequest request) {
        Product product = productRepository.findById(request.productId())
                .orElseThrow(() -> ApiException.notFound("Product not found"));
        if (!isPurchasable(product)) throw ApiException.badRequest("Product not available");

        CartItem item = cartItemRepository.findByUserAndProduct(user, product)
                .orElse(CartItem.builder().user(user).product(product).build());
        item.setQuantity(item.getId() == null ? request.quantity() : item.getQuantity() + request.quantity());
        cartItemRepository.save(item);
        return getCart(user);
    }

    @Override
    @Transactional
    public CartResponse updateQuantity(User user, Long productId, int quantity) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> ApiException.notFound("Product not found"));
        CartItem item = cartItemRepository.findByUserAndProduct(user, product)
                .orElseThrow(() -> ApiException.notFound("Cart item not found"));
        if (quantity <= 0) {
            cartItemRepository.delete(item);
        } else {
            item.setQuantity(quantity);
            cartItemRepository.save(item);
        }
        return getCart(user);
    }

    private boolean isPurchasable(Product product) {
        return product.isActive()
                && product.getApprovalStatus() == ProductApprovalStatus.APPROVED
                && product.getStock() > 0;
    }

    @Override
    @Transactional
    public void removeItem(User user, Long productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> ApiException.notFound("Product not found"));
        cartItemRepository.findByUserAndProduct(user, product)
                .ifPresent(cartItemRepository::delete);
    }

    @Override
    @Transactional
    public void clear(User user) {
        cartItemRepository.deleteByUser(user);
    }
}
