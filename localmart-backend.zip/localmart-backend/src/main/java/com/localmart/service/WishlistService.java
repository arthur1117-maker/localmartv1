package com.localmart.service;

import com.localmart.dto.response.product.ProductResponse;
import com.localmart.entity.User;

import java.util.List;

public interface WishlistService {
    List<ProductResponse> list(User user);
    void add(User user, Long productId);
    void remove(User user, Long productId);
}
