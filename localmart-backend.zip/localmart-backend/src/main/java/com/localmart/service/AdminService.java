package com.localmart.service;

import com.localmart.dto.response.admin.AdminAnalyticsResponse;
import com.localmart.dto.response.user.AdminUserResponse;

import java.util.List;

public interface AdminService {
    List<AdminUserResponse> allUsers();
    void toggleUserActive(String id);
    void verifyUser(String id);
    AdminAnalyticsResponse analytics();
}
