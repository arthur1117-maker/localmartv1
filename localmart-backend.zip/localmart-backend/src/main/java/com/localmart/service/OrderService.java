package com.localmart.service;

import com.localmart.dto.request.order.CreateOrderRequest;
import com.localmart.dto.response.order.OrderResponse;
import com.localmart.entity.User;

import java.util.List;

public interface OrderService {
    OrderResponse createOrder(User buyer, CreateOrderRequest request);
    List<OrderResponse> myOrders(User buyer);
    List<OrderResponse> sellerOrders(User seller);
    OrderResponse getByNumber(User user, String orderNumber);
    OrderResponse updateStatus(User user, String orderNumber, String status);
}
