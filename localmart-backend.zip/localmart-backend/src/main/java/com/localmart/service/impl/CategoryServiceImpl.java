package com.localmart.service.impl;

import com.localmart.common.exception.ApiException;
import com.localmart.dto.response.category.CategoryResponse;
import com.localmart.mapper.CategoryMapper;
import com.localmart.repository.CategoryRepository;
import com.localmart.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;
    private final CategoryMapper categoryMapper;

    @Override
    public List<CategoryResponse> listActive() {
        return categoryRepository.findByActiveTrueOrderBySortOrderAsc().stream()
                .map(categoryMapper::toResponse)
                .toList();
    }

    @Override
    public CategoryResponse getById(Long id) {
        return categoryRepository.findById(id)
                .filter(c -> c.isActive())
                .map(categoryMapper::toResponse)
                .orElseThrow(() -> ApiException.notFound("Category not found"));
    }

    @Override
    public CategoryResponse getBySlug(String slug) {
        return categoryRepository.findBySlug(slug)
                .filter(c -> c.isActive())
                .map(categoryMapper::toResponse)
                .orElseThrow(() -> ApiException.notFound("Category not found"));
    }
}
