package com.localmart.service.impl;

import com.localmart.common.exception.ApiException;
import com.localmart.dto.request.chat.SendMessageRequest;
import com.localmart.dto.response.chat.ChatMessageResponse;
import com.localmart.entity.ChatMessage;
import com.localmart.entity.Product;
import com.localmart.entity.User;
import com.localmart.enums.NotificationType;
import com.localmart.mapper.ChatMapper;
import com.localmart.repository.ChatMessageRepository;
import com.localmart.repository.ProductRepository;
import com.localmart.repository.UserRepository;
import com.localmart.service.ChatService;
import com.localmart.service.support.NotificationPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ChatServiceImpl implements ChatService {

    private final ChatMessageRepository chatMessageRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final NotificationPublisher notificationPublisher;
    private final ChatMapper chatMapper;

    @Override
    @Transactional
    public ChatMessageResponse send(User sender, SendMessageRequest request) {
        User receiver = userRepository.findById(request.receiverId())
                .orElseThrow(() -> ApiException.notFound("Receiver not found"));
        Product product = null;
        if (request.productId() != null) {
            product = productRepository.findById(request.productId()).orElse(null);
        }

        ChatMessage message = ChatMessage.builder()
                .sender(sender)
                .receiver(receiver)
                .content(request.content().trim())
                .product(product)
                .build();
        chatMessageRepository.save(message);

        notificationPublisher.publish(receiver, NotificationType.CHAT, "💬",
                "Шинэ мессеж", sender.getName() + ": " + truncate(request.content(), 60));

        return chatMapper.toResponse(message);
    }

    @Override
    public List<ChatMessageResponse> conversation(User current, String partnerId) {
        User partner = userRepository.findById(partnerId)
                .orElseThrow(() -> ApiException.notFound("User not found"));
        return chatMessageRepository.findConversation(current, partner).stream()
                .map(chatMapper::toResponse)
                .toList();
    }

    @Override
    public long unreadCount(User user) {
        return chatMessageRepository.countUnread(user);
    }

    @Override
    @Transactional
    public void markRead(User receiver, String senderId) {
        User sender = userRepository.findById(senderId)
                .orElseThrow(() -> ApiException.notFound("Sender not found"));
        chatMessageRepository.markReadFromSender(sender, receiver);
    }

    private String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }
}
