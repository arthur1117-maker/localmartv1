package com.localmart.service.impl;

import com.localmart.common.exception.ApiException;
import com.localmart.dto.response.product.ProductResponse;
import com.localmart.entity.Product;
import com.localmart.entity.User;
import com.localmart.entity.WishlistItem;
import com.localmart.mapper.ProductMapper;
import com.localmart.repository.ProductRepository;
import com.localmart.repository.WishlistItemRepository;
import com.localmart.service.WishlistService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class WishlistServiceImpl implements WishlistService {

    private final WishlistItemRepository wishlistItemRepository;
    private final ProductRepository productRepository;
    private final ProductMapper productMapper;

    @Override
    public List<ProductResponse> list(User user) {
        return wishlistItemRepository.findByUserOrderByCreatedAtDesc(user).stream()
                .map(w -> productMapper.toResponse(w.getProduct()))
                .toList();
    }

    @Override
    @Transactional
    public void add(User user, Long productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> ApiException.notFound("Product not found"));
        if (!wishlistItemRepository.existsByUserAndProduct(user, product)) {
            wishlistItemRepository.save(WishlistItem.builder().user(user).product(product).build());
        }
    }

    @Override
    @Transactional
    public void remove(User user, Long productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> ApiException.notFound("Product not found"));
        wishlistItemRepository.deleteByUserAndProduct(user, product);
    }
}
