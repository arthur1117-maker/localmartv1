package com.localmart.service;

import com.localmart.dto.request.review.ReviewRequest;
import com.localmart.dto.response.review.ReviewResponse;
import com.localmart.entity.User;

import java.util.List;

public interface ReviewService {
    List<ReviewResponse> byProduct(Long productId);
    ReviewResponse create(User buyer, ReviewRequest request);
}
