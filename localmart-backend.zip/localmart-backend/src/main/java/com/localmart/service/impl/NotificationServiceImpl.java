package com.localmart.service.impl;

import com.localmart.common.exception.ApiException;
import com.localmart.dto.response.notification.NotificationResponse;
import com.localmart.entity.Notification;
import com.localmart.entity.User;
import com.localmart.mapper.NotificationMapper;
import com.localmart.repository.NotificationRepository;
import com.localmart.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;
    private final NotificationMapper notificationMapper;

    @Override
    public List<NotificationResponse> all(User user) {
        return notificationRepository.findByUserOrderByCreatedAtDesc(user).stream()
                .map(notificationMapper::toResponse)
                .toList();
    }

    @Override
    public long unreadCount(User user) {
        return notificationRepository.countByUserAndIsReadFalse(user);
    }

    @Override
    @Transactional
    public void markRead(User user, Long id) {
        Notification n = notificationRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("Notification not found"));
        if (!n.getUser().getId().equals(user.getId())) {
            throw ApiException.forbidden("Access denied");
        }
        n.setRead(true);
    }

    @Override
    @Transactional
    public void markAllRead(User user) {
        notificationRepository.markAllRead(user);
    }
}
