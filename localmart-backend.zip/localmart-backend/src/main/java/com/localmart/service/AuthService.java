package com.localmart.service;

import com.localmart.dto.request.auth.LoginRequest;
import com.localmart.dto.request.auth.RegisterRequest;
import com.localmart.dto.response.auth.AuthResponse;
import com.localmart.entity.User;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
    AuthResponse refresh(String rawRefreshToken);
    void logout(String rawRefreshToken);
    void logoutAll(User user);
}
