package com.localmart.service;

import com.localmart.dto.request.cart.CartItemRequest;
import com.localmart.dto.response.cart.CartResponse;
import com.localmart.entity.User;

public interface CartService {
    CartResponse getCart(User user);
    CartResponse addItem(User user, CartItemRequest request);
    CartResponse updateQuantity(User user, Long productId, int quantity);
    void removeItem(User user, Long productId);
    void clear(User user);
}
