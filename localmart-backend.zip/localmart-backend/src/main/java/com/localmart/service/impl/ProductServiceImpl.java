package com.localmart.service.impl;

import com.localmart.common.exception.ApiException;
import com.localmart.common.pagination.PageQuery;
import com.localmart.common.pagination.PageResponse;
import com.localmart.common.pagination.PaginationUtils;
import com.localmart.dto.request.product.ProductApprovalRequest;
import com.localmart.dto.request.product.ProductRequest;
import com.localmart.dto.request.product.StockUpdateRequest;
import com.localmart.dto.response.product.ProductResponse;
import com.localmart.entity.Category;
import com.localmart.entity.Product;
import com.localmart.entity.User;
import com.localmart.enums.ProductApprovalStatus;
import com.localmart.enums.Role;
import com.localmart.mapper.ProductMapper;
import com.localmart.repository.ProductRepository;
import com.localmart.repository.specification.ProductSpecifications;
import com.localmart.service.CategoryResolver;
import com.localmart.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final ProductMapper productMapper;
    private final CategoryResolver categoryResolver;

    @Override
    @Transactional(readOnly = true)
    public PageResponse<ProductResponse> search(String q, String category, Long categoryId, String aimag,
                                                BigDecimal minPrice, BigDecimal maxPrice, BigDecimal minRating,
                                                Boolean verifiedOnly, Boolean inStock, Boolean isNew, Boolean isOrganic,
                                                String sort, int page, int size) {
        return searchWithSpecs(buildPublicSpecs(q, category, categoryId, aimag, minPrice, maxPrice, minRating,
                verifiedOnly, inStock, isNew, isOrganic), sort, page, size);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<ProductResponse> searchSellerInventory(User seller, String q, ProductApprovalStatus approvalStatus,
                                                               Boolean active, String sort, int page, int size) {
        requireSeller(seller);
        List<Specification<Product>> specs = new ArrayList<>();
        specs.add(ProductSpecifications.sellerId(parseUserId(seller)));
        addIfNotNull(specs, ProductSpecifications.searchQuery(q));
        addIfNotNull(specs, ProductSpecifications.approvalStatus(approvalStatus));
        if (active != null) {
            specs.add((root, query, cb) -> cb.equal(root.get("active"), active));
        }
        return searchWithSpecs(combine(specs), sort, page, size);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<ProductResponse> searchPendingApproval(int page, int size) {
        List<Specification<Product>> specs = List.of(
                ProductSpecifications.approvalStatus(ProductApprovalStatus.PENDING),
                ProductSpecifications.activeOnly()
        );
        return searchWithSpecs(combine(specs), "newest", page, size);
    }

    @Override
    @Transactional(readOnly = true)
    public ProductResponse getById(Long id) {
        Product product = loadProduct(id);
        if (!isPubliclyVisible(product)) {
            throw ApiException.notFound("Product not found");
        }
        return productMapper.toResponse(product);
    }

    @Override
    @Transactional(readOnly = true)
    public ProductResponse getByIdForSeller(User seller, Long id) {
        requireSeller(seller);
        Product product = loadProduct(id);
        assertOwnership(seller, product);
        return productMapper.toResponse(product);
    }

    // ХУУЧИН: Page буцаадаг байсныг List болгож зассан
    @Override
    @Transactional(readOnly = true)
    public List<ProductResponse> myProducts(User seller) {
        requireSeller(seller);
        List<Product> products = productRepository.findBySellerOrderByCreatedAtDesc(seller);
        return products.stream()
                .map(productMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional
    public ProductResponse create(User seller, ProductRequest request) {
        requireSeller(seller);
        Category category = categoryResolver.resolve(request.categoryId(), request.category());
        Product product = Product.builder()
                .seller(seller)
                .category(category)
                .verified(seller.isVerified())
                .active(true)
                .approvalStatus(seller.isVerified()
                        ? ProductApprovalStatus.APPROVED
                        : ProductApprovalStatus.PENDING)
                .stock(request.stock() != null ? request.stock() : 0)
                .build();
        productMapper.applyRequest(product, category, seller, request);
        return productMapper.toResponse(productRepository.save(product));
    }

    @Override
    @Transactional
    public ProductResponse update(User seller, Long id, ProductRequest request) {
        Product product = getOwnedProduct(seller, id);
        Category category = categoryResolver.resolve(request.categoryId(), request.category());
        productMapper.applyRequest(product, category, seller, request);
        if (product.getApprovalStatus() == ProductApprovalStatus.REJECTED) {
            product.setApprovalStatus(ProductApprovalStatus.PENDING);
            product.setRejectionReason(null);
        }
        return productMapper.toResponse(productRepository.save(product));
    }

    @Override
    @Transactional
    public ProductResponse updateStock(User seller, Long id, StockUpdateRequest request) {
        Product product = getOwnedProduct(seller, id);
        product.setStock(request.stock());
        return productMapper.toResponse(productRepository.save(product));
    }

    @Override
    @Transactional
    public void delete(User seller, Long id) {
        Product product = getOwnedProduct(seller, id);
        product.setActive(false);
        productRepository.save(product);
    }

    @Override
    @Transactional
    public ProductResponse approve(Long id) {
        Product product = loadProduct(id);
        product.setApprovalStatus(ProductApprovalStatus.APPROVED);
        product.setRejectionReason(null);
        product.setActive(true);
        return productMapper.toResponse(productRepository.save(product));
    }

    @Override
    @Transactional
    public ProductResponse reject(Long id, ProductApprovalRequest request) {
        Product product = loadProduct(id);
        product.setApprovalStatus(ProductApprovalStatus.REJECTED);
        product.setRejectionReason(request != null ? request.reason() : null);
        product.setActive(false);
        return productMapper.toResponse(productRepository.save(product));
    }

    @Override
    @Transactional
    public void toggleActive(Long id) {
        Product product = loadProduct(id);
        product.setActive(!product.isActive());
        productRepository.save(product);
    }

    private PageResponse<ProductResponse> searchWithSpecs(Specification<Product> spec, String sort, int page, int size) {
        PageQuery query = PageQuery.of(page, size, sort);
        Page<Product> result = productRepository.findAll(
                spec,
                PaginationUtils.toPageRequest(query, PaginationUtils.productSort(sort))
        );
        return PageResponse.from(result.map(productMapper::toResponse));
    }

    private Specification<Product> buildPublicSpecs(String q, String category, Long categoryId, String aimag,
                                                    BigDecimal minPrice, BigDecimal maxPrice, BigDecimal minRating,
                                                    Boolean verifiedOnly, Boolean inStock, Boolean isNew, Boolean isOrganic) {
        List<Specification<Product>> specs = new ArrayList<>();
        specs.add(ProductSpecifications.publicListing());
        addIfNotNull(specs, ProductSpecifications.searchQuery(q));
        addIfNotNull(specs, ProductSpecifications.categoryId(categoryId));
        if (categoryId == null) {
            addIfNotNull(specs, ProductSpecifications.categoryName(category));
        }
        addIfNotNull(specs, ProductSpecifications.aimag(aimag));
        addIfNotNull(specs, ProductSpecifications.minPrice(minPrice));
        addIfNotNull(specs, ProductSpecifications.maxPrice(maxPrice));
        addIfNotNull(specs, ProductSpecifications.minRating(minRating));
        addIfNotNull(specs, ProductSpecifications.verifiedOnly(verifiedOnly));
        addIfNotNull(specs, ProductSpecifications.inStockOnly(inStock));
        addIfNotNull(specs, ProductSpecifications.isNewOnly(isNew));
        addIfNotNull(specs, ProductSpecifications.isOrganicOnly(isOrganic));
        return combine(specs);
    }

    private Specification<Product> combine(List<Specification<Product>> specs) {
        return specs.stream()
                .reduce(Specification::and)
                .orElse((root, cq, cb) -> cb.conjunction());
    }

    private Product loadProduct(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("Product not found"));
    }

    private Product getOwnedProduct(User seller, Long id) {
        Product product = loadProduct(id);
        assertOwnership(seller, product);
        return product;
    }

    private void assertOwnership(User seller, Product product) {
        if (seller.getRole() == Role.ADMIN) {
            return;
        }
        if (!product.getSeller().getId().equals(seller.getId())) {
            throw ApiException.forbidden("Not your product");
        }
    }

    private boolean isPubliclyVisible(Product product) {
        return product.isActive()
                && product.getApprovalStatus() == ProductApprovalStatus.APPROVED;
    }

    private void requireSeller(User user) {
        if (user.getRole() != Role.SELLER && user.getRole() != Role.ADMIN) {
            throw ApiException.forbidden("Seller role required");
        }
    }

    // ЗАССАН: Long ID-г String болгож хөрвүүлсэн
    private String parseUserId(User user) {
        return String.valueOf(user.getId());
    }

    private void addIfNotNull(List<Specification<Product>> specs, Specification<Product> spec) {
        if (spec != null) specs.add(spec);
    }
}