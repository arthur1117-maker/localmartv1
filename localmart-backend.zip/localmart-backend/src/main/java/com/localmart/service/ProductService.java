package com.localmart.service;

import com.localmart.common.pagination.PageResponse;
import com.localmart.dto.request.product.ProductApprovalRequest;
import com.localmart.dto.request.product.ProductRequest;
import com.localmart.dto.request.product.StockUpdateRequest;
import com.localmart.dto.response.product.ProductResponse;
import com.localmart.entity.User;
import com.localmart.enums.ProductApprovalStatus;

import java.math.BigDecimal;
import java.util.List;

public interface ProductService {

    PageResponse<ProductResponse> search(String q, String category, Long categoryId, String aimag,
                                         BigDecimal minPrice, BigDecimal maxPrice, BigDecimal minRating,
                                         Boolean verifiedOnly, Boolean inStock, Boolean isNew, Boolean isOrganic,
                                         String sort, int page, int size);

    PageResponse<ProductResponse> searchSellerInventory(User seller, String q, ProductApprovalStatus approvalStatus,
                                                        Boolean active, String sort, int page, int size);

    PageResponse<ProductResponse> searchPendingApproval(int page, int size);

    ProductResponse getById(Long id);

    ProductResponse getByIdForSeller(User seller, Long id);

    List<ProductResponse> myProducts(User seller);

    ProductResponse create(User seller, ProductRequest request);

    ProductResponse update(User seller, Long id, ProductRequest request);

    ProductResponse updateStock(User seller, Long id, StockUpdateRequest request);

    void delete(User seller, Long id);

    ProductResponse approve(Long id);

    ProductResponse reject(Long id, ProductApprovalRequest request);

    void toggleActive(Long id);
}
