package com.localmart.service;

import com.localmart.dto.response.seller.SellerStatsResponse;
import com.localmart.entity.User;

public interface SellerAnalyticsService {
    SellerStatsResponse stats(User seller);
}
