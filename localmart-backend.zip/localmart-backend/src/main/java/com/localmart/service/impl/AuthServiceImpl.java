package com.localmart.service.impl;

import com.localmart.common.constants.AppConstants;
import com.localmart.common.exception.ApiException;
import com.localmart.common.util.HashUtils;
import com.localmart.dto.request.auth.LoginRequest;
import com.localmart.dto.request.auth.RegisterRequest;
import com.localmart.dto.response.auth.AuthResponse;
import com.localmart.entity.RefreshToken;
import com.localmart.entity.User;
import com.localmart.enums.Role;
import com.localmart.mapper.UserMapper;
import com.localmart.repository.RefreshTokenRepository;
import com.localmart.repository.UserRepository;
import com.localmart.security.JwtService;
import com.localmart.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final UserMapper userMapper;

    @Override
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        String email = normalizeEmail(request.email());
        if (userRepository.existsByEmailIgnoreCase(email)) {
            throw ApiException.conflict("Email already registered");
        }

        Role role = Role.fromApi(request.role());
        if (role == Role.ADMIN) {
            throw ApiException.forbidden("Cannot self-register as admin");
        }

        User user = User.builder()
                .name(request.name().trim())
                .email(email)
                .passwordHash(passwordEncoder.encode(request.password()))
                .role(role)
                .phone(request.phone())
                .aimag(request.aimag())
                .verified(role != Role.SELLER)
                .build();
        userRepository.save(user);
        return issueTokens(user);
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        String email = normalizeEmail(request.email());
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(email, request.password())
            );
        } catch (BadCredentialsException e) {
            throw ApiException.unauthorized("Invalid email or password");
        }

        User user = userRepository.findByEmailIgnoreCase(email)
                .orElseThrow(() -> ApiException.unauthorized("Invalid email or password"));
        if (!user.isActive()) {
            throw ApiException.forbidden("Account is disabled");
        }
        return issueTokens(user);
    }

    @Override
    @Transactional
    public AuthResponse refresh(String rawRefreshToken) {
        RefreshToken stored = findActiveRefreshToken(rawRefreshToken);
        if (stored.getExpiresAt().isBefore(Instant.now())) {
            stored.setRevoked(true);
            refreshTokenRepository.save(stored);
            throw ApiException.unauthorized("Refresh token expired");
        }

        // Rotate refresh token (one-time use)
        stored.setRevoked(true);
        refreshTokenRepository.save(stored);

        User user = stored.getUser();
        if (!user.isActive()) {
            throw ApiException.forbidden("Account is disabled");
        }
        return issueTokens(user);
    }

    @Override
    @Transactional
    public void logout(String rawRefreshToken) {
        refreshTokenRepository.revokeByTokenHash(HashUtils.sha256(rawRefreshToken));
    }

    @Override
    @Transactional
    public void logoutAll(User user) {
        refreshTokenRepository.revokeAllActiveByUser(user);
    }

    private AuthResponse issueTokens(User user) {
        String access = jwtService.generateAccessToken(user);
        String refreshValue = jwtService.generateRefreshTokenValue();
        refreshTokenRepository.save(RefreshToken.builder()
                .user(user)
                .tokenHash(HashUtils.sha256(refreshValue))
                .expiresAt(Instant.now().plusMillis(AppConstants.REFRESH_TOKEN_TTL_MS))
                .build());
        return userMapper.toAuthResponse(access, refreshValue, user);
    }

    private RefreshToken findActiveRefreshToken(String raw) {
        return refreshTokenRepository.findByTokenHashAndRevokedFalse(HashUtils.sha256(raw))
                .orElseThrow(() -> ApiException.unauthorized("Invalid refresh token"));
    }

    private String normalizeEmail(String email) {
        return email.trim().toLowerCase();
    }
}
