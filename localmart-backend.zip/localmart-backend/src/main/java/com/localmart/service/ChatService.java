package com.localmart.service;

import com.localmart.dto.request.chat.SendMessageRequest;
import com.localmart.dto.response.chat.ChatMessageResponse;
import com.localmart.entity.User;

import java.util.List;

public interface ChatService {
    ChatMessageResponse send(User sender, SendMessageRequest request);
    List<ChatMessageResponse> conversation(User current, String partnerId);
    long unreadCount(User user);
    void markRead(User receiver, String senderId);
}
