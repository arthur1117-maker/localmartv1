package com.localmart.service.impl;

import com.localmart.common.exception.ApiException;
import com.localmart.dto.response.seller.DayRevenueResponse;
import com.localmart.dto.response.seller.SellerStatsResponse;
import com.localmart.entity.User;
import com.localmart.enums.OrderStatus;
import com.localmart.enums.Role;
import com.localmart.mapper.SellerMapper;
import com.localmart.repository.OrderRepository;
import com.localmart.repository.ProductRepository;
import com.localmart.service.SellerAnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SellerAnalyticsServiceImpl implements SellerAnalyticsService {

    private static final String[] DAY_LABELS = {"Даваа", "Мягмар", "Лхагва", "Пүрэв", "Баасан", "Бямба", "Ням"};

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final SellerMapper sellerMapper;

    @Override
    public SellerStatsResponse stats(User seller) {
        if (seller.getRole() != Role.SELLER && seller.getRole() != Role.ADMIN) {
            throw ApiException.forbidden("Seller role required");
        }

        BigDecimal totalRevenue = orderRepository.sumRevenueBySeller(seller, OrderStatus.ЦУЦЛАСАН);
        long orderCount = orderRepository.countBySeller(seller);
        long productCount = productRepository.countBySeller(seller);

        var products = productRepository.findBySellerOrderByCreatedAtDesc(seller);
        BigDecimal avgRating = products.stream()
                .map(p -> p.getRatingAvg())
                .filter(r -> r.compareTo(BigDecimal.ZERO) > 0)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        long rated = products.stream()
                .filter(p -> p.getRatingAvg().compareTo(BigDecimal.ZERO) > 0)
                .count();
        BigDecimal avg = rated > 0
                ? avgRating.divide(BigDecimal.valueOf(rated), 2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

        return sellerMapper.toStatsResponse(
                totalRevenue != null ? totalRevenue : BigDecimal.ZERO,
                orderCount,
                productCount,
                avg,
                buildWeeklyRevenue(seller)
        );
    }

    private List<DayRevenueResponse> buildWeeklyRevenue(User seller) {
        ZoneId zone = ZoneId.systemDefault();
        Instant weekStart = Instant.now().atZone(zone)
                .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                .toLocalDate().atStartOfDay(zone).toInstant();

        List<DayRevenueResponse> days = new ArrayList<>();
        BigDecimal max = BigDecimal.ZERO;

        for (int i = 0; i < 7; i++) {
            Instant dayStart = weekStart.plusSeconds(i * 86400L);
            BigDecimal rev = orderRepository.sumRevenueSince(seller, dayStart, OrderStatus.ЦУЦЛАСАН);
            if (rev == null) rev = BigDecimal.ZERO;
            if (rev.compareTo(max) > 0) max = rev;
            days.add(sellerMapper.toDayRevenue(DAY_LABELS[i], rev, 0));
        }

        List<DayRevenueResponse> result = new ArrayList<>();
        for (DayRevenueResponse d : days) {
            int pct = max.compareTo(BigDecimal.ZERO) == 0 ? 0
                    : d.revenue().multiply(BigDecimal.valueOf(100)).divide(max, 0, RoundingMode.HALF_UP).intValue();
            result.add(sellerMapper.toDayRevenue(d.day(), d.revenue(), pct));
        }
        return result;
    }
}
