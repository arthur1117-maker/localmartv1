package com.localmart.service;

import com.localmart.dto.response.notification.NotificationResponse;
import com.localmart.entity.User;

import java.util.List;

public interface NotificationService {
    List<NotificationResponse> all(User user);
    long unreadCount(User user);
    void markRead(User user, Long id);
    void markAllRead(User user);
}
