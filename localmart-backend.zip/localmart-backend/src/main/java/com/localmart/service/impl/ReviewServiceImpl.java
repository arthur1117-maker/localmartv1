package com.localmart.service.impl;

import com.localmart.common.exception.ApiException;
import com.localmart.dto.request.review.ReviewRequest;
import com.localmart.dto.response.review.ReviewResponse;
import com.localmart.entity.Product;
import com.localmart.entity.Review;
import com.localmart.entity.User;
import com.localmart.enums.NotificationType;
import com.localmart.mapper.ReviewMapper;
import com.localmart.repository.ProductRepository;
import com.localmart.repository.ReviewRepository;
import com.localmart.service.ReviewService;
import com.localmart.service.support.NotificationPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;
    private final ProductRepository productRepository;
    private final NotificationPublisher notificationPublisher;
    private final ReviewMapper reviewMapper;

    @Override
    public List<ReviewResponse> byProduct(Long productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> ApiException.notFound("Product not found"));
        return reviewRepository.findByProductOrderByCreatedAtDesc(product).stream()
                .map(reviewMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional
    public ReviewResponse create(User buyer, ReviewRequest request) {
        Product product = productRepository.findById(request.productId())
                .orElseThrow(() -> ApiException.notFound("Product not found"));
        if (reviewRepository.existsByProductAndBuyer(product, buyer)) {
            throw ApiException.conflict("You already reviewed this product");
        }

        Review review = Review.builder()
                .product(product)
                .buyer(buyer)
                .rating(request.rating())
                .comment(request.comment().trim())
                .build();
        reviewRepository.save(review);
        recalculateRating(product);

        notificationPublisher.publish(product.getSeller(), NotificationType.SYSTEM, "⭐",
                "Шинэ үнэлгээ", buyer.getName() + " — " + request.rating() + " од");

        return reviewMapper.toResponse(review);
    }

    private void recalculateRating(Product product) {
        List<Review> reviews = reviewRepository.findByProductOrderByCreatedAtDesc(product);
        if (reviews.isEmpty()) return;
        double avg = reviews.stream().mapToInt(Review::getRating).average().orElse(0);
        product.setRatingAvg(BigDecimal.valueOf(avg).setScale(2, RoundingMode.HALF_UP));
        product.setReviewCount(reviews.size());
        productRepository.save(product);
    }
}
