package com.localmart.service.impl;

import com.localmart.common.exception.ApiException;
import com.localmart.dto.response.admin.AdminAnalyticsResponse;
import com.localmart.dto.response.user.AdminUserResponse;
import com.localmart.entity.User;
import com.localmart.enums.OrderStatus;
import com.localmart.enums.Role;
import com.localmart.mapper.UserMapper;
import com.localmart.repository.OrderRepository;
import com.localmart.repository.ProductRepository;
import com.localmart.repository.UserRepository;
import com.localmart.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;
    private final UserMapper userMapper;

    @Override
    public List<AdminUserResponse> allUsers() {
        return userRepository.findAll().stream()
                .map(userMapper::toAdminResponse)
                .toList();
    }

    @Override
    @Transactional
    public void toggleUserActive(String id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("User not found"));
        if (user.getRole() == Role.ADMIN) {
            throw ApiException.forbidden("Cannot disable admin");
        }
        user.setActive(!user.isActive());
    }

    @Override
    @Transactional
    public void verifyUser(String id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("User not found"));
        if (user.getRole() != Role.SELLER) {
            throw ApiException.badRequest("Only sellers can be verified");
        }
        user.setVerified(true);
    }

    @Override
    public AdminAnalyticsResponse analytics() {
        BigDecimal revenue = orderRepository.findAll().stream()
                .filter(o -> o.getStatus() != OrderStatus.ЦУЦЛАСАН)
                .map(o -> o.getTotalAmount())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        long sellers = userRepository.countByRole(Role.SELLER);
        long buyers = userRepository.countByRole(Role.USER);
        long pending = userRepository.findByRole(Role.SELLER).stream().filter(u -> !u.isVerified()).count();

        return new AdminAnalyticsResponse(
                revenue,
                userRepository.count(),
                sellers,
                buyers,
                productRepository.countByActiveTrue(),
                orderRepository.count(),
                pending
        );
    }
}
