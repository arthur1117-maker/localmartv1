package com.localmart.service.impl;

import com.localmart.common.exception.ApiException;
import com.localmart.dto.request.order.CreateOrderRequest;
import com.localmart.dto.response.order.OrderResponse;
import com.localmart.entity.*;
import com.localmart.enums.NotificationType;
import com.localmart.enums.OrderStatus;
import com.localmart.enums.Role;
import com.localmart.mapper.OrderMapper;
import com.localmart.repository.OrderRepository;
import com.localmart.repository.ProductRepository;
import com.localmart.service.CartService;
import com.localmart.service.OrderService;
import com.localmart.service.support.NotificationPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final NotificationPublisher notificationPublisher;
    private final CartService cartService;
    private final OrderMapper orderMapper;

    @Override
    @Transactional
    public OrderResponse createOrder(User buyer, CreateOrderRequest request) {
        if (buyer.getRole() != Role.USER && buyer.getRole() != Role.ADMIN) {
            throw ApiException.forbidden("User role required to place orders");
        }

        Map<User, List<OrderItem>> sellerBuckets = new LinkedHashMap<>();

        for (var itemReq : request.items()) {
            Product product = productRepository.findById(itemReq.productId())
                    .orElseThrow(() -> ApiException.notFound("Product not found: " + itemReq.productId()));
            if (!product.isActive()
                    || product.getApprovalStatus() != com.localmart.enums.ProductApprovalStatus.APPROVED
                    || product.getStock() < itemReq.quantity()) {
                throw ApiException.badRequest("Product unavailable: " + product.getName());
            }
            User seller = product.getSeller();
            BigDecimal subtotal = product.getPrice().multiply(BigDecimal.valueOf(itemReq.quantity()));
            OrderItem line = OrderItem.builder()
                    .product(product)
                    .productName(product.getName())
                    .productEmoji(product.getEmoji())
                    .quantity(itemReq.quantity())
                    .unitPrice(product.getPrice())
                    .subtotal(subtotal)
                    .build();
            sellerBuckets.computeIfAbsent(seller, k -> new ArrayList<>()).add(line);
            product.setStock(product.getStock() - itemReq.quantity());
        }

        OrderResponse first = null;
        for (var entry : sellerBuckets.entrySet()) {
            User seller = entry.getKey();
            List<OrderItem> lines = entry.getValue();
            BigDecimal total = lines.stream().map(OrderItem::getSubtotal).reduce(BigDecimal.ZERO, BigDecimal::add);

            Order order = Order.builder()
                    .orderNumber(generateOrderNumber())
                    .buyer(buyer)
                    .seller(seller)
                    .status(OrderStatus.БАТАЛГААЖСАН)
                    .totalAmount(total)
                    .deliveryAddress(request.deliveryAddress())
                    .buyerPhone(request.buyerPhone())
                    .paymentMethod(request.paymentMethod())
                    .build();
            lines.forEach(li -> li.setOrder(order));
            order.getItems().addAll(lines);
            orderRepository.save(order);

            notificationPublisher.publish(seller, NotificationType.ORDER, "📦",
                    "Шинэ захиалга", buyer.getName() + " — ₮" + total);
            notificationPublisher.publish(buyer, NotificationType.ORDER, "✅",
                    "Захиалга баталгаажлаа", order.getOrderNumber());

            if (first == null) first = orderMapper.toResponse(order);
        }

        cartService.clear(buyer);
        return first;
    }

    @Override
    public List<OrderResponse> myOrders(User buyer) {
        return orderRepository.findByBuyerOrderByCreatedAtDesc(buyer).stream()
                .map(orderMapper::toResponse)
                .toList();
    }

    @Override
    public List<OrderResponse> sellerOrders(User seller) {
        return orderRepository.findBySellerOrderByCreatedAtDesc(seller).stream()
                .map(orderMapper::toResponse)
                .toList();
    }

    @Override
    public OrderResponse getByNumber(User user, String orderNumber) {
        Order order = orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> ApiException.notFound("Order not found"));
        if (!order.getBuyer().getId().equals(user.getId())
                && !order.getSeller().getId().equals(user.getId())
                && user.getRole() != Role.ADMIN) {
            throw ApiException.forbidden("Access denied");
        }
        return orderMapper.toResponse(order);
    }

    @Override
    @Transactional
    public OrderResponse updateStatus(User user, String orderNumber, String statusStr) {
        Order order = orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> ApiException.notFound("Order not found"));

        boolean isSeller = order.getSeller().getId().equals(user.getId());
        boolean isAdmin = user.getRole() == Role.ADMIN;
        if (!isSeller && !isAdmin) {
            throw ApiException.forbidden("Only seller or admin can update status");
        }

        OrderStatus newStatus;
        try {
            newStatus = OrderStatus.valueOf(statusStr.trim());
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("Invalid status: " + statusStr);
        }

        order.setStatus(newStatus);
        orderRepository.save(order);

        notificationPublisher.publish(order.getBuyer(), NotificationType.ORDER, "🚚",
                "Захиалгын төлөв шинэчлэгдлээ", order.getOrderNumber() + " → " + newStatus.name());

        return orderMapper.toResponse(order);
    }

    private String generateOrderNumber() {
        return "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}
