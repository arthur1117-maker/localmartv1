package com.localmart.service.support;

import com.localmart.entity.Notification;
import com.localmart.entity.User;
import com.localmart.enums.NotificationType;
import com.localmart.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class NotificationPublisher {

    private final NotificationRepository notificationRepository;

    public void publish(User user, NotificationType type, String icon, String title, String body) {
        notificationRepository.save(Notification.builder()
                .user(user)
                .type(type)
                .icon(icon)
                .title(title)
                .body(body)
                .build());
    }
}
