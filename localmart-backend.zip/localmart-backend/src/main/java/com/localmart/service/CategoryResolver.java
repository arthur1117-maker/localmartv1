package com.localmart.service;

import com.localmart.common.exception.ApiException;
import com.localmart.entity.Category;
import com.localmart.repository.CategoryRepository;
import com.localmart.util.SlugUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CategoryResolver {

    private final CategoryRepository categoryRepository;

    public Category resolve(Long categoryId, String categoryNameOrSlug) {
        if (categoryId != null) {
            return categoryRepository.findById(categoryId)
                    .filter(Category::isActive)
                    .orElseThrow(() -> ApiException.badRequest("Invalid category id: " + categoryId));
        }
        if (categoryNameOrSlug == null || categoryNameOrSlug.isBlank()) {
            throw ApiException.badRequest("Category is required");
        }
        String value = categoryNameOrSlug.trim();
        return categoryRepository.findByNameIgnoreCase(value)
                .or(() -> categoryRepository.findBySlug(SlugUtils.slugify(value)))
                .filter(Category::isActive)
                .orElseThrow(() -> ApiException.badRequest("Unknown category: " + value));
    }
}
