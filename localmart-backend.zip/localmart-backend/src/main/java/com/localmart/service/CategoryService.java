package com.localmart.service;

import com.localmart.dto.response.category.CategoryResponse;

import java.util.List;

public interface CategoryService {
    List<CategoryResponse> listActive();
    CategoryResponse getById(Long id);
    CategoryResponse getBySlug(String slug);
}
