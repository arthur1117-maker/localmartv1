package com.localmart.enums;

/**
 * Platform roles. API exposes {@code buyer} for {@link #USER} (Next.js frontend compatibility).
 */
public enum Role {
    USER,
    SELLER,
    ADMIN;

    /** Value returned in JSON API responses. */
    public String toApiValue() {
        return switch (this) {
            case USER -> "buyer";
            case SELLER -> "seller";
            case ADMIN -> "admin";
        };
    }

    /** Spring Security authority name. */
    public String toAuthority() {
        return "ROLE_" + name();
    }

    public static Role fromApi(String value) {
        if (value == null || value.isBlank()) {
            return USER;
        }
        String normalized = value.trim().toLowerCase();
        return switch (normalized) {
            case "buyer", "user" -> USER;
            case "seller" -> SELLER;
            case "admin" -> ADMIN;
            default -> Role.valueOf(value.trim().toUpperCase());
        };
    }
}
