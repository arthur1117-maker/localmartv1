package com.localmart.enums;

public enum OrderStatus {
    БАТАЛГААЖСАН("БАТАЛГААЖСАН"),
    БЭЛТГЭЖ_БАЙНА("БЭЛТГЭЖ БАЙНА"),
    ХҮРГЭЛТЭНД("ХҮРГЭЛТЭНД"),
    ХҮРГЭГДСЭН("ХҮРГЭГДСЭН"),
    ЦУЦЛАСАН("ЦУЦЛАСАН");

    private final String label;

    OrderStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
