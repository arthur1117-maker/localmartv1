package com.localmart.enums;

public enum ProductApprovalStatus {
    PENDING,
    APPROVED,
    REJECTED
}
