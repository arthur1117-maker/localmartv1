package com.localmart.enums;

public enum NotificationType {
    ORDER,
    CHAT,
    PROMO,
    SYSTEM
}
