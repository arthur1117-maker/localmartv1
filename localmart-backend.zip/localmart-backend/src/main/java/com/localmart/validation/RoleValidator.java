package com.localmart.validation;

import com.localmart.enums.Role;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class RoleValidator implements ConstraintValidator<ValidRole, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null || value.isBlank()) {
            return false;
        }
        try {
            Role role = Role.fromApi(value);
            return role == Role.USER || role == Role.SELLER;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
