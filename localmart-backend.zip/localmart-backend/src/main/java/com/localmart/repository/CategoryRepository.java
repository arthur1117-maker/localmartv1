package com.localmart.repository;

import com.localmart.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    Optional<Category> findBySlug(String slug);
    Optional<Category> findByNameIgnoreCase(String name);
    List<Category> findByActiveTrueOrderBySortOrderAsc();
    boolean existsBySlug(String slug);
}
