package com.localmart.repository;

import com.localmart.entity.User;
import com.localmart.enums.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, String> {
    Optional<User> findByEmailIgnoreCase(String email);
    boolean existsByEmailIgnoreCase(String email);
    List<User> findByRole(Role role);
    long countByRole(Role role);
    long countByVerifiedTrue();
    long countByActiveTrue();
}
