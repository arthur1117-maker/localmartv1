package com.localmart.repository;

import com.localmart.entity.Order;
import com.localmart.entity.User;
import com.localmart.enums.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, Long> {
    Optional<Order> findByOrderNumber(String orderNumber);
    List<Order> findByBuyerOrderByCreatedAtDesc(User buyer);
    List<Order> findBySellerOrderByCreatedAtDesc(User seller);
    List<Order> findAllByOrderByCreatedAtDesc();

    @Query("SELECT COALESCE(SUM(o.totalAmount), 0) FROM Order o WHERE o.seller = :seller AND o.status <> :cancelled")
    BigDecimal sumRevenueBySeller(@Param("seller") User seller, @Param("cancelled") OrderStatus cancelled);

    long countBySeller(User seller);

    @Query("SELECT COALESCE(SUM(o.totalAmount), 0) FROM Order o WHERE o.seller = :seller AND o.createdAt >= :since AND o.status <> :cancelled")
    BigDecimal sumRevenueSince(@Param("seller") User seller, @Param("since") Instant since, @Param("cancelled") OrderStatus cancelled);

    @Query("SELECT COUNT(o) FROM Order o WHERE o.seller = :seller AND o.createdAt >= :since")
    long countOrdersSince(@Param("seller") User seller, @Param("since") Instant since);
}
