package com.localmart.repository;

import com.localmart.entity.ChatMessage;
import com.localmart.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {

    @Query("""
        SELECT m FROM ChatMessage m
        WHERE (m.sender = :u1 AND m.receiver = :u2) OR (m.sender = :u2 AND m.receiver = :u1)
        ORDER BY m.sentAt ASC
        """)
    List<ChatMessage> findConversation(@Param("u1") User u1, @Param("u2") User u2);

    @Query("SELECT COUNT(m) FROM ChatMessage m WHERE m.receiver = :user AND m.isRead = false")
    long countUnread(@Param("user") User user);

    @Modifying
    @Query("UPDATE ChatMessage m SET m.isRead = true WHERE m.sender = :sender AND m.receiver = :receiver AND m.isRead = false")
    int markReadFromSender(@Param("sender") User sender, @Param("receiver") User receiver);
}
