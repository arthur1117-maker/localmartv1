package com.localmart.repository;

import com.localmart.entity.Product;
import com.localmart.entity.User;
import com.localmart.enums.ProductApprovalStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long>, JpaSpecificationExecutor<Product> {

    // ЭНИЙГ НЭМСЭН: DataSeeder дээр бараа давхардаж орохоос сэргийлнэ
    boolean existsBySlug(String slug);

    @EntityGraph(attributePaths = {"seller", "category", "images"})
    @Override
    Optional<Product> findById(Long id);

    @EntityGraph(attributePaths = {"seller", "category"})
    @Override
    Page<Product> findAll(Specification<Product> spec, Pageable pageable);

    @EntityGraph(attributePaths = {"category", "images"})
    List<Product> findBySellerOrderByCreatedAtDesc(User seller);

    long countBySeller(User seller);

    long countByActiveTrue();

    long countByApprovalStatus(ProductApprovalStatus status);

    @Query("SELECT COUNT(p) FROM Product p WHERE p.seller = :seller AND p.approvalStatus = :status")
    long countBySellerAndApprovalStatus(@Param("seller") User seller, @Param("status") ProductApprovalStatus status);
}