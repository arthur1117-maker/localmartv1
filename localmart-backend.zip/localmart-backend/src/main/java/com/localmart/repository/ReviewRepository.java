package com.localmart.repository;

import com.localmart.entity.Product;
import com.localmart.entity.Review;
import com.localmart.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByProductOrderByCreatedAtDesc(Product product);
    Optional<Review> findByProductAndBuyer(Product product, User buyer);
    boolean existsByProductAndBuyer(Product product, User buyer);
}
