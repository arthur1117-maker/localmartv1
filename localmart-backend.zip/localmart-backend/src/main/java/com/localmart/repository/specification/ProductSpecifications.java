package com.localmart.repository.specification;

import com.localmart.entity.Product;
import com.localmart.enums.ProductApprovalStatus;
import jakarta.persistence.criteria.JoinType;
import org.springframework.data.jpa.domain.Specification;

import java.math.BigDecimal;

public final class ProductSpecifications {

    private ProductSpecifications() {}

    /** Public marketplace listings. */
    public static Specification<Product> publicListing() {
        return approved().and(activeOnly());
    }

    public static Specification<Product> approved() {
        return (root, query, cb) -> cb.equal(root.get("approvalStatus"), ProductApprovalStatus.APPROVED);
    }

    public static Specification<Product> activeOnly() {
        return (root, query, cb) -> cb.isTrue(root.get("active"));
    }

    public static Specification<Product> approvalStatus(ProductApprovalStatus status) {
        if (status == null) return null;
        return (root, query, cb) -> cb.equal(root.get("approvalStatus"), status);
    }

    public static Specification<Product> sellerId(String sellerId) {
        if (sellerId == null || sellerId.isBlank()) return null;
        return (root, query, cb) -> cb.equal(root.get("seller").get("id"), sellerId);
    }

    public static Specification<Product> searchQuery(String q) {
        if (q == null || q.isBlank()) return null;
        String pattern = "%" + q.trim().toLowerCase() + "%";
        return (root, query, cb) -> {
            var category = root.join("category", JoinType.LEFT);
            return cb.or(
                    cb.like(cb.lower(root.get("name")), pattern),
                    cb.like(cb.lower(root.get("story")), pattern),
                    cb.like(cb.lower(category.get("name")), pattern),
                    cb.like(cb.lower(root.get("aimag")), pattern)
            );
        };
    }

    public static Specification<Product> categoryName(String category) {
        if (category == null || category.isBlank()) return null;
        String name = category.trim();
        return (root, query, cb) -> {
            var cat = root.join("category");
            return cb.equal(cb.lower(cat.get("name")), name.toLowerCase());
        };
    }

    public static Specification<Product> categoryId(Long categoryId) {
        if (categoryId == null) return null;
        return (root, query, cb) -> cb.equal(root.get("category").get("id"), categoryId);
    }

    public static Specification<Product> aimag(String aimag) {
        if (aimag == null || aimag.isBlank()) return null;
        return (root, query, cb) -> cb.equal(root.get("aimag"), aimag.trim());
    }

    public static Specification<Product> maxPrice(BigDecimal maxPrice) {
        if (maxPrice == null) return null;
        return (root, query, cb) -> cb.lessThanOrEqualTo(root.get("price"), maxPrice);
    }

    public static Specification<Product> minPrice(BigDecimal minPrice) {
        if (minPrice == null) return null;
        return (root, query, cb) -> cb.greaterThanOrEqualTo(root.get("price"), minPrice);
    }

    public static Specification<Product> minRating(BigDecimal minRating) {
        if (minRating == null) return null;
        return (root, query, cb) -> cb.greaterThanOrEqualTo(root.get("ratingAvg"), minRating);
    }

    public static Specification<Product> verifiedOnly(Boolean verifiedOnly) {
        if (verifiedOnly == null || !verifiedOnly) return null;
        return (root, query, cb) -> cb.isTrue(root.get("verified"));
    }

    public static Specification<Product> inStockOnly(Boolean inStock) {
        if (inStock == null || !inStock) return null;
        return (root, query, cb) -> cb.greaterThan(root.get("stock"), 0);
    }

    public static Specification<Product> isNewOnly(Boolean isNew) {
        if (isNew == null || !isNew) return null;
        return (root, query, cb) -> cb.isTrue(root.get("isNew"));
    }

    public static Specification<Product> isOrganicOnly(Boolean isOrganic) {
        if (isOrganic == null || !isOrganic) return null;
        return (root, query, cb) -> cb.isTrue(root.get("isOrganic"));
    }
}
