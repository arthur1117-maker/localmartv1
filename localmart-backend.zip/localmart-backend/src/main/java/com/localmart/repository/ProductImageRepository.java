package com.localmart.repository;

import com.localmart.entity.Product;
import com.localmart.entity.ProductImage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductImageRepository extends JpaRepository<ProductImage, Long> {
    List<ProductImage> findByProductOrderBySortOrderAsc(Product product);
    void deleteByProduct(Product product);
}
