package com.localmart.dto.response.review;

import java.time.Instant;

public record ReviewResponse(
        Long id,
        int rating,
        String comment,
        String buyerName,
        Instant createdAt
) {}
