package com.localmart.dto.response.seller;

import java.math.BigDecimal;

public record DayRevenueResponse(String day, BigDecimal revenue, int pct) {}
