package com.localmart.dto.response.admin;

import java.math.BigDecimal;

public record AdminAnalyticsResponse(
        BigDecimal totalRevenue,
        long totalUsers,
        long sellerCount,
        long buyerCount,
        long activeProducts,
        long totalOrders,
        long pendingSellerVerifications
) {}
