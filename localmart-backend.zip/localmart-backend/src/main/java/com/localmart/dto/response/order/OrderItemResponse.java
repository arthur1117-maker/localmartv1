package com.localmart.dto.response.order;

import java.math.BigDecimal;

public record OrderItemResponse(
        String productName,
        String productEmoji,
        int quantity,
        BigDecimal unitPrice,
        BigDecimal subtotal
) {}
