package com.localmart.dto.request.order;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public record CreateOrderRequest(
        @NotEmpty @Valid List<OrderItemRequest> items,
        @NotBlank String deliveryAddress,
        @NotBlank String buyerPhone,
        @NotBlank String paymentMethod
) {}
