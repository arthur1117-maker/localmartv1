package com.localmart.dto.response.cart;

import com.localmart.dto.response.product.ProductResponse;

import java.math.BigDecimal;
import java.util.List;

public record CartResponse(
        List<CartLineResponse> items,
        BigDecimal total,
        int count
) {}
