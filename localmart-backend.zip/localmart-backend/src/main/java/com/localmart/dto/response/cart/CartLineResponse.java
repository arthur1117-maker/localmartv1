package com.localmart.dto.response.cart;

import com.localmart.dto.response.product.ProductResponse;

public record CartLineResponse(ProductResponse product, int quantity) {}
