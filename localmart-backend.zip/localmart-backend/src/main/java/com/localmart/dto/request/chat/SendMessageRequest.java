package com.localmart.dto.request.chat;

import jakarta.validation.constraints.NotBlank;

public record SendMessageRequest(
        @NotBlank String receiverId,
        @NotBlank String content,
        Long productId
) {}
