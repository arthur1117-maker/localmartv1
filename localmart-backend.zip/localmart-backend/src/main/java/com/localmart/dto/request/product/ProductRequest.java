package com.localmart.dto.request.product;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.util.List;

public record ProductRequest(
        @NotBlank @Size(max = 200) String name,
        @NotNull @DecimalMin("0.01") BigDecimal price,
        @NotBlank @Size(max = 30) String unit,
        /** Category display name (preferred for frontend). */
        @NotBlank @Size(max = 80) String category,
        /** Optional category id when known. */
        Long categoryId,
        @NotBlank @Size(max = 80) String aimag,
        @Size(max = 8) String emoji,
        @Size(max = 5000) String story,
        @Min(0) Integer stock,
        List<@NotBlank @Size(max = 500) String> imageUrls,
        Boolean isNew,
        Boolean isOrganic,
        @Size(max = 20) String sellerPhone
) {}
