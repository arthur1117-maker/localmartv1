package com.localmart.dto.response.user;

public record UserResponse(
        String id,
        String name,
        String email,
        String role,
        String phone,
        String aimag,
        boolean verified,
        boolean active,
        String avatar
) {}
