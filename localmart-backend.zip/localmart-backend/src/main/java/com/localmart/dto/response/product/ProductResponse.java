package com.localmart.dto.response.product;

import com.localmart.enums.ProductApprovalStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

/**
 * Public catalog shape aligned with the Next.js {@code ProductDto}.
 * Extra fields ({@code imageUrls}, {@code approvalStatus}, {@code categoryId}) are ignored by the UI.
 */
public record ProductResponse(
        Long id,
        String name,
        BigDecimal price,
        String unit,
        String category,
        Long categoryId,
        String aimag,
        String emoji,
        String story,
        BigDecimal rating,
        int reviewCount,
        int stock,
        int imageCount,
        List<String> imageUrls,
        boolean isNew,
        boolean isOrganic,
        boolean verified,
        boolean active,
        ProductApprovalStatus approvalStatus,
        String seller,
        String sellerPhone,
        Instant createdAt
) {}
