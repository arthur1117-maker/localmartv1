package com.localmart.dto.response.user;

public record AdminUserResponse(
        String id,
        String name,
        String email,
        String role,
        String aimag,
        boolean verified,
        boolean active,
        String joined,
        String avatar
) {}
