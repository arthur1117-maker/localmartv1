package com.localmart.dto.response.auth;

import com.localmart.dto.response.user.UserResponse;

public record AuthResponse(
        String accessToken,
        String refreshToken,
        UserResponse user
) {}
