package com.localmart.dto.request.product;

import jakarta.validation.constraints.Size;

public record ProductApprovalRequest(
        @Size(max = 500) String reason
) {}
