package com.localmart.dto.response.order;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public record OrderResponse(
        Long id,
        String orderNumber,
        String status,
        BigDecimal totalAmount,
        String deliveryAddress,
        String buyerPhone,
        String paymentMethod,
        String buyer,
        String seller,
        Instant createdAt,
        List<OrderItemResponse> items
) {}
