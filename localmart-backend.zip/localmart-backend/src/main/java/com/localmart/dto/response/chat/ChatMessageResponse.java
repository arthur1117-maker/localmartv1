package com.localmart.dto.response.chat;

import java.time.Instant;

public record ChatMessageResponse(
        Long id,
        String senderId,
        String senderName,
        String receiverId,
        String content,
        boolean isRead,
        Instant sentAt,
        Long productId
) {}
