package com.localmart.dto.response.seller;

import java.math.BigDecimal;
import java.util.List;

public record SellerStatsResponse(
        BigDecimal totalRevenue,
        long orderCount,
        long productCount,
        BigDecimal avgRating,
        List<DayRevenueResponse> weeklyRevenue
) {}
