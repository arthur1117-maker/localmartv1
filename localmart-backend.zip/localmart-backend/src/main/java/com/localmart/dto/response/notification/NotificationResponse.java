package com.localmart.dto.response.notification;

import java.time.Instant;

public record NotificationResponse(
        Long id,
        String type,
        String icon,
        String title,
        String body,
        boolean isRead,
        Instant createdAt
) {}
