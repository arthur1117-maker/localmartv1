package com.localmart.dto.response.category;

public record CategoryResponse(
        Long id,
        String name,
        String slug,
        String icon,
        String colorHex,
        String bgHex,
        int sortOrder
) {}
