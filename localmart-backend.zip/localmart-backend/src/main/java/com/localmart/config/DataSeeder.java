package com.localmart.config;

import com.localmart.entity.Category;
import com.localmart.entity.Product;
import com.localmart.entity.ProductImage;
import com.localmart.entity.User;
import com.localmart.enums.ProductApprovalStatus;
import com.localmart.enums.Role;
import com.localmart.repository.CategoryRepository;
import com.localmart.repository.ProductRepository;
import com.localmart.repository.UserRepository;
import com.localmart.util.SlugUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Хэрэв дата хэдийнэ орсон байвал алгасна
        if (userRepository.count() > 0) {
            log.info("Database already seeded. Skipping DataSeeder...");
            return;
        }

        log.info("Starting LocalMart development data seeding...");

        // 1. Хэрэглэгчид үүсгэх
        User admin = saveUser("admin@localmart.mn", "Admin123!", "Админ", Role.ADMIN, "Улаанбаатар", "⚙️", true, true);
        User seller = saveUser("seller@test.mn", "Seller123!", "Б. Мөнхбаяр", Role.SELLER, "Увс", "👨‍🌾", true, true);
        User seller2 = saveUser("seller2@test.mn", "Seller123!", "Д. Эрдэнэ", Role.SELLER, "Архангай", "🧑‍🌾", true, true);
        User buyer = saveUser("buyer@test.mn", "Buyer123!", "Б. Тэмүүжин", Role.USER, "Улаанбаатар", "👤", false, true);

        // 2. Категориуд үүсгэх
        Map<String, Category> categories = seedCategories();

        // 3. Бараанууд үүсгэх
        seedProduct(seller, categories.get("Ноос ноолуур"), "Ямааны цэвэр ноолуур", 85000, "кг", "Увс", "🧶",
                "Увс аймгийн Наранбулаг сумын малчин Б. Мөнхбаярын 500 ямаанаас авсан цэвэр цагаан ноолуур.",
                12, List.of("https://images.localmart.mn/products/wool-1.jpg"), true, false, true, "99112233", 4.8, 24);

        seedProduct(seller2, categories.get("Мах"), "Хонины чандмань гуяз", 42000, "кг", "Архангай", "🥩",
                "Архангай аймгийн Тариат сумын малчин Д. Эрдэнийн өвс бэлчээрт өссөн 200 хоньноос.",
                5, List.of("https://images.localmart.mn/products/meat-1.jpg"), false, true, true, "88223344", 4.9, 51);

        seedProduct(seller, categories.get("Цагаан идээ"), "Гэрийн аргал айраг 2л", 8000, "литр", "Өвөрхангай", "🥛",
                "Өвөрхангай аймгийн уламжлалт аргаар исгэсэн цэвэр гүүний айраг.",
                20, List.of("https://images.localmart.mn/products/airag-1.jpg"), false, true, false, "77334455", 4.6, 18);

        seedProduct(seller2, categories.get("Гар урлал"), "Эсгий гутал (гардан)", 120000, "ш", "Хөвсгөл", "🎨",
                "Хөвсгөл аймгийн уран гар урчин Т. Болормаагийн гар аргаар хийсэн эсгий гутал.",
                2, List.of("https://images.localmart.mn/products/felt-1.jpg"), true, false, true, "99445566", 5.0, 9);

        log.info("Data seeding completed successfully.");
    }

    private Map<String, Category> seedCategories() {
        Map<String, Category> map = new LinkedHashMap<>();
        String[][] rows = {
                {"Мах", "🥩", "#dc2626", "#fef2f2", "1"},
                {"Цагаан идээ", "🥛", "#06b6d4", "#eff6ff", "2"},
                {"Ноос ноолуур", "🧶", "#7c3aed", "#f5f3ff", "3"},
                {"Гар урлал", "🎨", "#b45309", "#fffbeb", "4"},
                {"Тариалан", "🌾", "#10b981", "#f0fdf4", "5"},
                {"Байгалийн бүт.", "🍯", "#ca8a04", "#fefce8", "6"},
                {"Загас", "🐟", "#0891b2", "#ecfeff", "7"},
                {"Эмийн ургамал", "🌿", "#059669", "#ecfdf5", "8"},
        };
        for (String[] row : rows) {
            String slug = SlugUtils.slugify(row[0]);
            Category cat = categoryRepository.findBySlug(slug)
                    .orElseGet(() -> categoryRepository.save(Category.builder()
                            .name(row[0])
                            .slug(slug)
                            .icon(row[1])
                            .colorHex(row[2])
                            .bgHex(row[3])
                            .sortOrder(Integer.parseInt(row[4]))
                            .active(true)
                            .build()));
            map.put(row[0], cat);
        }
        return map;
    }

    private User saveUser(String email, String password, String name, Role role, String aimag,
                          String avatar, boolean verified, boolean active) {
        User user = User.builder()
                .id(UUID.randomUUID().toString()) // CHAR(36) UUID
                .email(email)
                .passwordHash(passwordEncoder.encode(password)) // Entity-ийн passwordHash талбарт оноов
                .name(name)
                .role(role)
                .aimag(aimag)
                .avatar(avatar)
                .verified(verified) // Entity-ийн verified (is_verified)
                .active(active)     // Entity-ийн active (is_active)
                .createdAt(Instant.now())
                .updatedAt(Instant.now())
                .build();
        return userRepository.save(user);
    }

    private void seedProduct(User seller, Category category, String name, int price, String unit,
                             String aimag, String emoji, String story, int stock, List<String> imageUrls,
                             boolean isNew, boolean isOrganic, boolean verified, String phone,
                             double rating, int reviews) {

        String slug = SlugUtils.slugify(name);
        if (productRepository.existsBySlug(slug)) return;

        Product p = Product.builder()
                .seller(seller)
                .category(category)
                .name(name)
                .slug(slug)
                .price(BigDecimal.valueOf(price))
                .unit(unit)
                .aimag(aimag)
                .emoji(emoji)
                .story(story)
                .stock(stock)
                .isNew(isNew)
                .isOrganic(isOrganic)
                .verified(verified)
                .sellerPhone(phone)
                .ratingAvg(BigDecimal.valueOf(rating))
                .reviewCount(reviews)
                .active(true)
                .approvalStatus(ProductApprovalStatus.APPROVED)
                .build();

        // Зургуудыг холбох
        for (int i = 0; i < imageUrls.size(); i++) {
            p.getImages().add(ProductImage.builder()
                    .product(p)
                    .imageUrl(imageUrls.get(i))
                    .sortOrder(i)
                    .primary(i == 0)
                    .build());
        }
        productRepository.save(p);
    }
}