package com.localmart.config;

import com.localmart.security.JwtAuthenticationFilter;
import com.localmart.security.LocalMartUserDetailsService;
import com.localmart.security.SecurityConstants;
import com.localmart.security.handler.JwtAccessDeniedHandler;
import com.localmart.security.handler.JwtAuthenticationEntryPoint;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final JwtAuthenticationEntryPoint authenticationEntryPoint;
    private final JwtAccessDeniedHandler accessDeniedHandler;
    private final LocalMartUserDetailsService userDetailsService;

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .cors(c -> {})
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint(authenticationEntryPoint)
                        .accessDeniedHandler(accessDeniedHandler)
                )
                .authorizeHttpRequests(auth -> auth
                        // 1. Нэвтрэлт болон бүртгэлийн цэгүүдийг нээлттэй болгох
                        .requestMatchers(SecurityConstants.PUBLIC_AUTH).permitAll()
                        .requestMatchers(SecurityConstants.PUBLIC_MISC).permitAll()

                        // 2. БАРАА БҮТЭЭГДЭХҮҮН, КАТЕГОРИЙГ НЭЭЛТТЭЙ БОЛГОХ (ЗАССАН)
                        // Үүнийг нэмснээр нэвтрээгүй хэрэглэгч бараа харах боломжтой болно
                        .requestMatchers(HttpMethod.GET, "/api/products/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/categories/**").permitAll()
                        .requestMatchers(HttpMethod.GET, SecurityConstants.PUBLIC_GET).permitAll()

                        // 3. Эрхээр хамгаалагдсан хэсгүүд
                        .requestMatchers("/api/admin/**").hasRole("ADMIN")
                        .requestMatchers("/api/seller/**").hasAnyRole("SELLER", "ADMIN")

                        // 4. Бусад бүх API хүсэлтүүд заавал JWT токен шаардана
                        .requestMatchers(HttpMethod.POST, "/api/auth/logout-all").authenticated()
                        .requestMatchers("/api/**").authenticated()

                        // 5. Бусад бүх төрлийн хүсэлтийг (Static files гм) зөвшөөрөх
                        .anyRequest().permitAll()
                )
                .headers(h -> h.frameOptions(f -> f.sameOrigin()))
                .authenticationProvider(authenticationProvider())
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        provider.setHideUserNotFoundExceptions(true);
        return provider;
    }

    @Bean
    PasswordEncoder passwordEncoder() {
        // BCrypt ашиглан нууц үгийг 12 удаагийн давтамжтай хаш хийнэ
        return new BCryptPasswordEncoder(12);
    }

    @Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}