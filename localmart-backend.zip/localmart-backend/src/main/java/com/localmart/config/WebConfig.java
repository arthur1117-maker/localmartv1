package com.localmart.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.web.config.EnableSpringDataWebSupport;

@Configuration
// Параметрийг нь (pageSerializationMode = VIA_DTO) бүрэн устга
@EnableSpringDataWebSupport
public class WebConfig {
    // Дотор нь өөр код байхгүй бол ингээд л болоо
}