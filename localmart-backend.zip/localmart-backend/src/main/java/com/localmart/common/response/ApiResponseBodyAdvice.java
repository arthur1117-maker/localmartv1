package com.localmart.common.response;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.common.pagination.PageResponse;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * Wraps successful responses in {@link ApiResponse} unless {@link DirectResponse} is present
 * or the body is already wrapped / is a pagination contract.
 */
@RestControllerAdvice(basePackages = "com.localmart.controller")
public class ApiResponseBodyAdvice implements ResponseBodyAdvice<Object> {

    @Override
    public boolean supports(@NonNull MethodParameter returnType,
                            @NonNull Class<? extends HttpMessageConverter<?>> converterType) {
        if (returnType.getContainingClass().isAnnotationPresent(DirectResponse.class)) {
            return false;
        }
        if (returnType.hasMethodAnnotation(DirectResponse.class)) {
            return false;
        }
        Class<?> type = returnType.getParameterType();
        return type != ApiResponse.class
                && type != PageResponse.class
                && !Void.TYPE.equals(type)
                && !void.class.equals(type);
    }

    @Override
    public Object beforeBodyWrite(
            @Nullable Object body,
            @NonNull MethodParameter returnType,
            @NonNull MediaType selectedContentType,
            @NonNull Class<? extends HttpMessageConverter<?>> selectedConverterType,
            @NonNull ServerHttpRequest request,
            @NonNull ServerHttpResponse response
    ) {
        if (body == null) {
            return null;
        }
        if (body instanceof ApiResponse) {
            return body;
        }
        return ApiResponse.success(body);
    }
}
