package com.localmart.common.pagination;

import org.springframework.data.domain.Page;

import java.util.List;

/**
 * Pagination contract aligned with the Next.js frontend ({@code PageResponse<T>}).
 */
public record PageResponse<T>(
        List<T> content,
        long totalElements,
        int totalPages,
        int number,
        int size
) {
    public static <T> PageResponse<T> from(Page<T> page) {
        return new PageResponse<>(
                page.getContent(),
                page.getTotalElements(),
                page.getTotalPages(),
                page.getNumber(),
                page.getSize()
        );
    }
}
