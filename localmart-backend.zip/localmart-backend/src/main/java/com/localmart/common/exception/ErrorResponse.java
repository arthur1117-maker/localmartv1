package com.localmart.common.exception;

import java.time.Instant;

/**
 * Error payload — includes {@code message} for frontend {@code lib/api} compatibility.
 */
public record ErrorResponse(
        Instant timestamp,
        int status,
        String error,
        String message,
        String path
) {}
