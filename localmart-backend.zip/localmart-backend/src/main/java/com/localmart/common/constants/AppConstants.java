package com.localmart.common.constants;

public final class AppConstants {

    private AppConstants() {}

    public static final String API_PREFIX = "/api";
    public static final int DEFAULT_PAGE_SIZE = 24;
    public static final int MAX_PAGE_SIZE = 100;
    public static final long REFRESH_TOKEN_TTL_MS = 604_800_000L;
}
