package com.localmart.common.annotation;

import java.lang.annotation.*;

/**
 * Marks controller methods/classes whose response body is returned directly
 * without {@link com.localmart.common.response.ApiResponse} wrapping.
 * Used for Next.js frontend API contract compatibility.
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface DirectResponse {
}
