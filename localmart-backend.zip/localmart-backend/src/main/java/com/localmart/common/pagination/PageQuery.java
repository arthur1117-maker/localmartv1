package com.localmart.common.pagination;

import com.localmart.common.constants.AppConstants;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

public record PageQuery(
        @Min(0) int page,
        @Min(1) @Max(AppConstants.MAX_PAGE_SIZE) int size,
        String sort
) {
    public static PageQuery of(int page, int size, String sort) {
        int safeSize = Math.min(Math.max(size, 1), AppConstants.MAX_PAGE_SIZE);
        return new PageQuery(Math.max(page, 0), safeSize, sort);
    }

    public static PageQuery defaults(String sort) {
        return of(0, AppConstants.DEFAULT_PAGE_SIZE, sort);
    }
}
