package com.localmart.common.pagination;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

public final class PaginationUtils {

    private PaginationUtils() {}

    public static PageRequest toPageRequest(PageQuery query, Sort sort) {
        return PageRequest.of(query.page(), query.size(), sort);
    }

    public static Sort productSort(String sortKey) {
        if (sortKey == null) {
            return Sort.by(Sort.Direction.DESC, "createdAt");
        }
        return switch (sortKey) {
            case "price_asc" -> Sort.by(Sort.Direction.ASC, "price");
            case "price_desc" -> Sort.by(Sort.Direction.DESC, "price");
            case "rating" -> Sort.by(Sort.Direction.DESC, "ratingAvg");
            case "stock_asc" -> Sort.by(Sort.Direction.ASC, "stock");
            case "stock_desc" -> Sort.by(Sort.Direction.DESC, "stock");
            case "name_asc" -> Sort.by(Sort.Direction.ASC, "name");
            default -> Sort.by(Sort.Direction.DESC, "createdAt");
        };
    }
}
