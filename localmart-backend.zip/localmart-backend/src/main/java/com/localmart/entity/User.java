package com.localmart.entity;

import com.fasterxml.jackson.annotation.JsonIgnore; // Энийг нэмэх
import com.fasterxml.jackson.annotation.JsonIgnoreProperties; // Энийг нэмэх
import com.localmart.enums.Role;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "users", indexes = {
        @Index(name = "idx_users_email", columnList = "email", unique = true),
        @Index(name = "idx_users_role", columnList = "role"),
        @Index(name = "idx_users_active", columnList = "is_active")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
// ХАМГИЙН ЧУХАЛ: Hibernate-ийн Lazy Loading-аас болж 500 алдаа гарахаас сэргийлнэ
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class User {

    @Id
    @Column(length = 36, nullable = false, updatable = false)
    private String id;

    @Column(nullable = false, length = 120)
    private String name;

    @Column(nullable = false, length = 180, unique = true)
    private String email;

    @Column(name = "password_hash", nullable = false)
    @JsonIgnore // АЮУЛГҮЙ БАЙДАЛ: Нууц үгийг JSON хариунд хэзээ ч гаргаж болохгүй
    private String passwordHash;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Role role;

    @Column(length = 20)
    private String phone;

    @Column(length = 80)
    private String aimag;

    @Column(length = 16)
    @Builder.Default
    private String avatar = "👤";

    @Column(name = "is_verified", nullable = false)
    @Builder.Default
    private boolean verified = false;

    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private boolean active = true;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    void prePersist() {
        if (id == null) id = UUID.randomUUID().toString();
        if (createdAt == null) createdAt = Instant.now();
        if (updatedAt == null) updatedAt = Instant.now();

        if (avatar == null) {
            avatar = switch (role != null ? role : Role.USER) {
                case SELLER -> "👨‍🌾";
                case ADMIN -> "⚙️";
                default -> "👤";
            };
        }
    }

    @PreUpdate
    void preUpdate() {
        updatedAt = Instant.now();
    }
}