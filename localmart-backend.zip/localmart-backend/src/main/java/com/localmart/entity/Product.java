package com.localmart.entity;

import com.localmart.enums.ProductApprovalStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.BatchSize;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "products", indexes = {
        @Index(name = "idx_products_seller", columnList = "seller_id"),
        @Index(name = "idx_products_category", columnList = "category_id"),
        @Index(name = "idx_products_aimag_active", columnList = "aimag, is_active"), // SQL схемтэй тааруулав
        @Index(name = "idx_products_price", columnList = "price"),
        @Index(name = "idx_products_rating", columnList = "rating_avg"),
        @Index(name = "idx_products_created", columnList = "created_at")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "seller_id", nullable = false)
    private User seller;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(length = 220)
    private String slug;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal price;

    @Column(nullable = false, length = 30)
    private String unit;

    @Column(nullable = false, length = 80)
    private String aimag;

    @Column(nullable = false, length = 8)
    @Builder.Default
    private String emoji = "📦";

    @Column(columnDefinition = "TEXT")
    private String story;

    @Column(name = "stock_quantity", nullable = false)
    @Builder.Default
    private int stock = 0;

    // SQL схем дээрх 'is_new' баганатай холбов
    @Column(name = "is_new", nullable = false)
    @Builder.Default
    private boolean isNew = false;

    // SQL схем дээрх 'is_organic' баганатай холбов
    @Column(name = "is_organic", nullable = false)
    @Builder.Default
    private boolean isOrganic = false;

    // SQL схем дээрх 'is_verified' баганатай холбов
    @Column(name = "is_verified", nullable = false)
    @Builder.Default
    private boolean verified = false;

    // SQL схем дээрх 'is_active' баганатай холбов
    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private boolean active = true;

    @Enumerated(EnumType.STRING)
    @Column(name = "approval_status", nullable = false, length = 20)
    @Builder.Default
    private ProductApprovalStatus approvalStatus = ProductApprovalStatus.PENDING;

    @Column(name = "rejection_reason", length = 500)
    private String rejectionReason;

    @Column(name = "rating_avg", precision = 3, scale = 2) // Нэрийг тааруулав
    @Builder.Default
    private BigDecimal ratingAvg = BigDecimal.ZERO;

    @Column(name = "review_count") // Нэрийг тааруулав
    @Builder.Default
    private int reviewCount = 0;

    @Column(name = "seller_phone", length = 20)
    private String sellerPhone;

    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("sortOrder ASC")
    @BatchSize(size = 25)
    @Builder.Default
    private List<ProductImage> images = new ArrayList<>();
}