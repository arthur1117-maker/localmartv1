package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.dto.response.product.ProductResponse;
import com.localmart.security.SecurityUtils;
import com.localmart.service.WishlistService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/wishlist")
@RequiredArgsConstructor
@DirectResponse
public class WishlistController {

    private final WishlistService wishlistService;

    @GetMapping
    public List<ProductResponse> list() {
        return wishlistService.list(SecurityUtils.currentUser());
    }

    @PostMapping("/{productId}")
    public void add(@PathVariable Long productId) {
        wishlistService.add(SecurityUtils.currentUser(), productId);
    }

    @DeleteMapping("/{productId}")
    public void remove(@PathVariable Long productId) {
        wishlistService.remove(SecurityUtils.currentUser(), productId);
    }
}
