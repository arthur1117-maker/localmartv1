package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.dto.request.order.CreateOrderRequest;
import com.localmart.dto.request.order.UpdateOrderStatusRequest;
import com.localmart.dto.response.order.OrderResponse;
import com.localmart.security.SecurityUtils;
import com.localmart.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
@DirectResponse
public class OrderController {

    private final OrderService orderService;

    @PostMapping
    public OrderResponse create(@Valid @RequestBody CreateOrderRequest request) {
        return orderService.createOrder(SecurityUtils.currentUser(), request);
    }

    @GetMapping("/my")
    public List<OrderResponse> myOrders() {
        return orderService.myOrders(SecurityUtils.currentUser());
    }

    @GetMapping("/seller")
    @PreAuthorize("hasAnyRole('SELLER','ADMIN')")
    public List<OrderResponse> sellerOrders() {
        return orderService.sellerOrders(SecurityUtils.currentUser());
    }

    @GetMapping("/{orderNumber}")
    public OrderResponse get(@PathVariable String orderNumber) {
        return orderService.getByNumber(SecurityUtils.currentUser(), orderNumber);
    }

    @PatchMapping("/{orderNumber}/status")
    @PreAuthorize("hasAnyRole('SELLER','ADMIN')")
    public OrderResponse updateStatus(
            @PathVariable String orderNumber,
            @Valid @RequestBody UpdateOrderStatusRequest request
    ) {
        return orderService.updateStatus(SecurityUtils.currentUser(), orderNumber, request.status());
    }
}
