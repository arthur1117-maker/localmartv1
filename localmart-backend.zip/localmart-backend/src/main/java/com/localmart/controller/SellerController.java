package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.dto.response.seller.SellerStatsResponse;
import com.localmart.security.SecurityUtils;
import com.localmart.service.SellerAnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/seller")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('SELLER','ADMIN')")
@DirectResponse
public class SellerController {

    private final SellerAnalyticsService sellerAnalyticsService;

    @GetMapping("/stats")
    public SellerStatsResponse stats() {
        return sellerAnalyticsService.stats(SecurityUtils.currentUser());
    }
}
