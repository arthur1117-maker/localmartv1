package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.dto.request.review.ReviewRequest;
import com.localmart.dto.response.review.ReviewResponse;
import com.localmart.security.SecurityUtils;
import com.localmart.service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
@DirectResponse
public class ReviewController {

    private final ReviewService reviewService;

    @GetMapping("/product/{productId}")
    public List<ReviewResponse> byProduct(@PathVariable Long productId) {
        return reviewService.byProduct(productId);
    }

    @PostMapping
    public ReviewResponse create(@Valid @RequestBody ReviewRequest request) {
        return reviewService.create(SecurityUtils.currentUser(), request);
    }
}
