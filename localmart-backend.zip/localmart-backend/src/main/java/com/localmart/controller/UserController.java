package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.dto.response.user.UserResponse;
import com.localmart.mapper.UserMapper;
import com.localmart.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@DirectResponse
public class UserController {

    private final UserMapper userMapper;

    @GetMapping("/me")
    public UserResponse me() {
        return userMapper.toResponse(SecurityUtils.currentUser());
    }
}
