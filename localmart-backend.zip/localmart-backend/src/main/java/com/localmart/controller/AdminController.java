package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.common.pagination.PageResponse;
import com.localmart.dto.request.product.ProductApprovalRequest;
import com.localmart.dto.response.admin.AdminAnalyticsResponse;
import com.localmart.dto.response.product.ProductResponse;
import com.localmart.dto.response.user.AdminUserResponse;
import com.localmart.service.AdminService;
import com.localmart.service.ProductService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
@DirectResponse
public class AdminController {

    private final AdminService adminService;
    private final ProductService productService;

    @GetMapping("/users")
    public List<AdminUserResponse> users() {
        return adminService.allUsers();
    }

    @PatchMapping("/users/{id}/toggle-active")
    public void toggleActive(@PathVariable String id) {
        adminService.toggleUserActive(id);
    }

    @PatchMapping("/users/{id}/verify")
    public void verify(@PathVariable String id) {
        adminService.verifyUser(id);
    }

    @GetMapping("/products/pending")
    public PageResponse<ProductResponse> pendingProducts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size
    ) {
        return productService.searchPendingApproval(page, size);
    }

    @PatchMapping("/products/{id}/approve")
    public ProductResponse approveProduct(@PathVariable Long id) {
        return productService.approve(id);
    }

    @PatchMapping("/products/{id}/reject")
    public ProductResponse rejectProduct(@PathVariable Long id,
                                         @Valid @RequestBody(required = false) ProductApprovalRequest request) {
        return productService.reject(id, request);
    }

    @PatchMapping("/products/{id}/toggle-active")
    public void toggleProduct(@PathVariable Long id) {
        productService.toggleActive(id);
    }

    @GetMapping("/analytics/overview")
    public AdminAnalyticsResponse analytics() {
        return adminService.analytics();
    }
}
