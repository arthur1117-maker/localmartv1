package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.dto.response.notification.NotificationResponse;
import com.localmart.security.SecurityUtils;
import com.localmart.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
@DirectResponse
public class NotificationController {

    private final NotificationService notificationService;

    @GetMapping
    public List<NotificationResponse> all() {
        return notificationService.all(SecurityUtils.currentUser());
    }

    @GetMapping("/unread")
    public long unreadCount() {
        return notificationService.unreadCount(SecurityUtils.currentUser());
    }

    @PatchMapping("/{id}/read")
    public void markRead(@PathVariable Long id) {
        notificationService.markRead(SecurityUtils.currentUser(), id);
    }

    @PatchMapping("/read-all")
    public void markAllRead() {
        notificationService.markAllRead(SecurityUtils.currentUser());
    }
}
