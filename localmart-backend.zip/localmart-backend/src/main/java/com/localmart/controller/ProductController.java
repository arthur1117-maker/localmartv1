package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.common.pagination.PageResponse;
import com.localmart.dto.request.product.ProductRequest;
import com.localmart.dto.request.product.StockUpdateRequest;
import com.localmart.dto.response.product.ProductResponse;
import com.localmart.enums.ProductApprovalStatus;
import com.localmart.security.SecurityUtils;
import com.localmart.service.ProductService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
@DirectResponse
public class ProductController {

    private final ProductService productService;

    @GetMapping("/search")
    public PageResponse<ProductResponse> search(
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) String aimag,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @RequestParam(required = false) BigDecimal minRating,
            @RequestParam(required = false) Boolean verifiedOnly,
            @RequestParam(required = false) Boolean inStock,
            @RequestParam(required = false) Boolean isNew,
            @RequestParam(required = false) Boolean isOrganic,
            @RequestParam(defaultValue = "newest") String sort,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "24") int size
    ) {
        return productService.search(q, category, categoryId, aimag, minPrice, maxPrice, minRating,
                verifiedOnly, inStock, isNew, isOrganic, sort, page, size);
    }

    @GetMapping("/me")
    @PreAuthorize("hasAnyRole('SELLER','ADMIN')")
    public List<ProductResponse> myProducts() {
        return productService.myProducts(SecurityUtils.currentUser());
    }

    @GetMapping("/me/search")
    @PreAuthorize("hasAnyRole('SELLER','ADMIN')")
    public PageResponse<ProductResponse> myProductsSearch(
            @RequestParam(required = false) String q,
            @RequestParam(required = false) ProductApprovalStatus approvalStatus,
            @RequestParam(required = false) Boolean active,
            @RequestParam(defaultValue = "newest") String sort,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "24") int size
    ) {
        return productService.searchSellerInventory(SecurityUtils.currentUser(), q, approvalStatus, active, sort, page, size);
    }

    @GetMapping("/{id}")
    public ProductResponse get(@PathVariable Long id) {
        return productService.getById(id);
    }

    @GetMapping("/{id}/manage")
    @PreAuthorize("hasAnyRole('SELLER','ADMIN')")
    public ProductResponse getForSeller(@PathVariable Long id) {
        return productService.getByIdForSeller(SecurityUtils.currentUser(), id);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SELLER','ADMIN')")
    public ProductResponse create(@Valid @RequestBody ProductRequest request) {
        return productService.create(SecurityUtils.currentUser(), request);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('SELLER','ADMIN')")
    public ProductResponse update(@PathVariable Long id, @Valid @RequestBody ProductRequest request) {
        return productService.update(SecurityUtils.currentUser(), id, request);
    }

    @PatchMapping("/{id}/stock")
    @PreAuthorize("hasAnyRole('SELLER','ADMIN')")
    public ProductResponse updateStock(@PathVariable Long id, @Valid @RequestBody StockUpdateRequest request) {
        return productService.updateStock(SecurityUtils.currentUser(), id, request);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('SELLER','ADMIN')")
    public void delete(@PathVariable Long id) {
        productService.delete(SecurityUtils.currentUser(), id);
    }
}
