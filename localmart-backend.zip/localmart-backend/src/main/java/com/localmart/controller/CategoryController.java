package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.dto.response.category.CategoryResponse;
import com.localmart.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
@DirectResponse
public class CategoryController {

    private final CategoryService categoryService;

    @GetMapping
    public List<CategoryResponse> list() {
        return categoryService.listActive();
    }

    @GetMapping("/{idOrSlug}")
    public CategoryResponse get(@PathVariable String idOrSlug) {
        try {
            return categoryService.getById(Long.parseLong(idOrSlug));
        } catch (NumberFormatException e) {
            return categoryService.getBySlug(idOrSlug);
        }
    }
}
