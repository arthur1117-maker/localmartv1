package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.dto.request.auth.LoginRequest;
import com.localmart.dto.request.auth.LogoutRequest;
import com.localmart.dto.request.auth.RefreshRequest;
import com.localmart.dto.request.auth.RegisterRequest;
import com.localmart.dto.response.auth.AuthResponse;
import com.localmart.security.SecurityUtils;
import com.localmart.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@DirectResponse
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        return authService.login(request);
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthResponse register(@Valid @RequestBody RegisterRequest request) {
        return authService.register(request);
    }

    @PostMapping("/refresh")
    public AuthResponse refresh(@Valid @RequestBody RefreshRequest request) {
        return authService.refresh(request.refreshToken());
    }

    /**
     * Revokes a single refresh token (client should also discard access token locally).
     */
    @PostMapping("/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logout(@Valid @RequestBody LogoutRequest request) {
        authService.logout(request.refreshToken());
    }

    /**
     * Revokes all refresh tokens for the authenticated user (global sign-out).
     */
    @PostMapping("/logout-all")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logoutAll() {
        authService.logoutAll(SecurityUtils.currentUser());
    }
}
