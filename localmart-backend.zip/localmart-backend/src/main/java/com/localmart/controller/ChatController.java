package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.dto.request.chat.SendMessageRequest;
import com.localmart.dto.response.chat.ChatMessageResponse;
import com.localmart.security.SecurityUtils;
import com.localmart.service.ChatService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
@DirectResponse
public class ChatController {

    private final ChatService chatService;

    @PostMapping("/send")
    public ChatMessageResponse send(@Valid @RequestBody SendMessageRequest request) {
        return chatService.send(SecurityUtils.currentUser(), request);
    }

    @GetMapping("/conversation/{partnerId}")
    public List<ChatMessageResponse> conversation(@PathVariable String partnerId) {
        return chatService.conversation(SecurityUtils.currentUser(), partnerId);
    }

    @GetMapping("/unread")
    public long unreadCount() {
        return chatService.unreadCount(SecurityUtils.currentUser());
    }

    @PatchMapping("/read/{senderId}")
    public void markRead(@PathVariable String senderId) {
        chatService.markRead(SecurityUtils.currentUser(), senderId);
    }
}
