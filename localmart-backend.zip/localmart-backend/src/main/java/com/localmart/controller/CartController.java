package com.localmart.controller;

import com.localmart.common.annotation.DirectResponse;
import com.localmart.dto.request.cart.CartItemRequest;
import com.localmart.dto.response.cart.CartResponse;
import com.localmart.security.SecurityUtils;
import com.localmart.service.CartService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
@RequiredArgsConstructor
@DirectResponse
public class CartController {

    private final CartService cartService;

    @GetMapping
    public CartResponse getCart() {
        return cartService.getCart(SecurityUtils.currentUser());
    }

    @PostMapping("/items")
    public CartResponse addItem(@Valid @RequestBody CartItemRequest request) {
        return cartService.addItem(SecurityUtils.currentUser(), request);
    }

    @PutMapping("/items/{productId}")
    public CartResponse update(
            @PathVariable Long productId,
            @RequestParam int quantity
    ) {
        return cartService.updateQuantity(SecurityUtils.currentUser(), productId, quantity);
    }

    @DeleteMapping("/items/{productId}")
    public void remove(@PathVariable Long productId) {
        cartService.removeItem(SecurityUtils.currentUser(), productId);
    }

    @DeleteMapping
    public void clear() {
        cartService.clear(SecurityUtils.currentUser());
    }
}
