# JWT Authentication — LocalMart API

Production Spring Security + JWT architecture for stateless API access.

## Roles

| Internal (`Role` enum) | Spring authority | API JSON value | Description |
|----------------------|------------------|----------------|-------------|
| `USER` | `ROLE_USER` | `buyer` | Marketplace customer |
| `SELLER` | `ROLE_SELLER` | `seller` | Product seller |
| `ADMIN` | `ROLE_ADMIN` | `admin` | Platform administrator |

Registration accepts `user`, `buyer`, or `seller` (not `admin`).

## Token model

| Token | Format | Lifetime | Storage |
|-------|--------|----------|---------|
| **Access** | JWT (HS256) | 15 min (configurable) | Client memory / header |
| **Refresh** | Opaque UUID | 7 days | DB (`refresh_tokens`, SHA-256 hash) |

Access JWT claims: `sub` (user id), `typ=access`, `email`, `role`.

## Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/auth/register` | Public | Create account + tokens |
| POST | `/api/auth/login` | Public | Authenticate + tokens |
| POST | `/api/auth/refresh` | Public | Rotate refresh token |
| POST | `/api/auth/logout` | Public | Revoke one refresh token |
| POST | `/api/auth/logout-all` | Bearer | Revoke all sessions |

### Login / register response

```json
{
  "accessToken": "eyJhbG...",
  "refreshToken": "uuid.uuid",
  "user": {
    "id": "...",
    "email": "buyer@test.mn",
    "role": "buyer",
    "verified": false,
    "active": true
  }
}
```

### Authenticated requests

```
Authorization: Bearer <accessToken>
```

## Security filter chain

```
Request
  → JwtAuthenticationFilter (middleware)
      → Parse Bearer token
      → Validate JWT typ=access
      → Load UserDetails
      → Set SecurityContext
  → Authorization (URL + @PreAuthorize)
  → Controller
```

Public routes skip the JWT filter for `/api/auth/login`, `/register`, `/refresh`.

## Protected routes

| Pattern | Required role |
|---------|---------------|
| `/api/admin/**` | `ADMIN` |
| `/api/seller/**` | `SELLER` or `ADMIN` |
| `/api/**` (other) | Any authenticated user |
| GET `/api/products/search`, `/api/products/{id}` | Public |

## Password policy (register)

- Minimum 8 characters
- At least one uppercase, lowercase, and digit
- Hashed with **BCrypt strength 12**

## Configuration (`application.yml`)

```yaml
app:
  jwt:
    secret: ${JWT_SECRET:change-me-in-production}
    access-expiration-ms: 900000
    refresh-expiration-ms: 604800000
```

## Error responses

| Status | When |
|--------|------|
| 401 | Missing/invalid/expired access token |
| 403 | Disabled account or insufficient role |
| 400 | Validation failed (password, email, role) |

All errors return `{ timestamp, status, error, message, path }`.

## Test accounts (dev seed)

| Email | Password | Role |
|-------|----------|------|
| buyer@test.mn | Buyer123! | USER (API: buyer) |
| seller@test.mn | Seller123! | SELLER |
| admin@localmart.mn | Admin123! | ADMIN |
