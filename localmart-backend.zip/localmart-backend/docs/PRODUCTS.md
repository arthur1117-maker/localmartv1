# Product management API

Base path: `/api`

## Categories (public)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/categories` | List active categories |
| GET | `/categories/{idOrSlug}` | Category by id or slug |

## Catalog (public)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/products/search` | Paginated search (`q`, `category`, `categoryId`, `aimag`, `minPrice`, `maxPrice`, `minRating`, `verifiedOnly`, `inStock`, `isNew`, `isOrganic`, `sort`, `page`, `size`) |
| GET | `/products/{id}` | Approved + active product detail |

Public search returns only **APPROVED** and **active** listings.

## Seller (JWT: SELLER or ADMIN)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/products/me` | All seller products (list) |
| GET | `/products/me/search` | Paginated seller inventory with filters |
| GET | `/products/{id}/manage` | Own product (any approval status) |
| POST | `/products` | Create product (`ProductRequest` + optional `imageUrls`) |
| PUT | `/products/{id}` | Update (ownership enforced) |
| PATCH | `/products/{id}/stock` | `{ "stock": 0 }` |
| DELETE | `/products/{id}` | Soft-delete (sets `active=false`) |

**Approval on create:** verified sellers → `APPROVED`; others → `PENDING`.

## Admin (JWT: ADMIN)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/admin/products/pending` | Paginated pending approvals |
| PATCH | `/admin/products/{id}/approve` | Approve listing |
| PATCH | `/admin/products/{id}/reject` | Reject (`{ "reason": "..." }` optional) |
| PATCH | `/admin/products/{id}/toggle-active` | Toggle active flag |

## Request body (`ProductRequest`)

```json
{
  "name": "Ямааны ноолуур",
  "price": 85000,
  "unit": "кг",
  "category": "Ноос ноолуур",
  "categoryId": 3,
  "aimag": "Увс",
  "emoji": "🧶",
  "story": "...",
  "stock": 10,
  "imageUrls": ["https://cdn.example/img1.jpg"],
  "isNew": true,
  "isOrganic": false,
  "sellerPhone": "99112233"
}
```

## Response (`ProductResponse`)

Compatible with frontend `ProductDto` (`rating`, `imageCount`, `category`, etc.) plus optional `imageUrls`, `categoryId`, `approvalStatus`.

## Sort keys

`newest` (default), `price_asc`, `price_desc`, `rating`, `stock_asc`, `stock_desc`, `name_asc`
