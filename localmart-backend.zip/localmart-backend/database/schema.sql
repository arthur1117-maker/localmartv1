-- =============================================================================
-- LocalMart Connected — Production MySQL Schema
-- Version: 1.0.0
-- Engine: InnoDB | Charset: utf8mb4 | Collation: utf8mb4_unicode_ci
-- =============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS localmart
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE localmart;

-- -----------------------------------------------------------------------------
-- ENUM types (MySQL 8+)
-- -----------------------------------------------------------------------------

-- Note: MySQL ENUM used inline per column for portability with JPA @Enumerated(STRING)

-- -----------------------------------------------------------------------------
-- 1. USERS & ROLE PROFILES
-- -----------------------------------------------------------------------------

CREATE TABLE users (
    id              CHAR(36)        NOT NULL,
    name            VARCHAR(120)    NOT NULL,
    email           VARCHAR(180)    NOT NULL,
    password_hash   VARCHAR(255)    NOT NULL,
    role            ENUM('USER', 'SELLER', 'ADMIN') NOT NULL DEFAULT 'USER',
    phone           VARCHAR(20)     NULL,
    aimag           VARCHAR(80)     NULL COMMENT 'Mongolia province / aimag',
    avatar          VARCHAR(16)     NULL DEFAULT '👤',
    is_verified     TINYINT(1)      NOT NULL DEFAULT 0 COMMENT 'Seller verification flag',
    is_active       TINYINT(1)      NOT NULL DEFAULT 1,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT uk_users_email UNIQUE (email),
    INDEX idx_users_role (role),
    INDEX idx_users_active (is_active),
    INDEX idx_users_aimag (aimag)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='All platform accounts: buyers, sellers, admins';

CREATE TABLE seller_profiles (
    user_id             CHAR(36)        NOT NULL,
    shop_name           VARCHAR(150)    NOT NULL,
    shop_description    TEXT            NULL,
    business_phone      VARCHAR(20)     NULL,
    business_aimag      VARCHAR(80)     NULL,
    is_verified         TINYINT(1)      NOT NULL DEFAULT 0 COMMENT 'Admin-approved seller',
    verified_at         TIMESTAMP(3)    NULL,
    verified_by         CHAR(36)        NULL COMMENT 'Admin user who verified',
    total_sales         DECIMAL(14,2)   NOT NULL DEFAULT 0.00,
    rating_avg          DECIMAL(3,2)    NOT NULL DEFAULT 0.00,
    product_count       INT UNSIGNED    NOT NULL DEFAULT 0,
    created_at          TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at          TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (user_id),
    INDEX idx_seller_profiles_verified (is_verified),
    INDEX idx_seller_profiles_aimag (business_aimag),
    CONSTRAINT fk_seller_profiles_user
        FOREIGN KEY (user_id) REFERENCES users (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_seller_profiles_verified_by
        FOREIGN KEY (verified_by) REFERENCES users (id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Extended profile for users with role SELLER';

CREATE TABLE admin_profiles (
    user_id         CHAR(36)        NOT NULL,
    department      VARCHAR(100)    NULL DEFAULT 'Platform Operations',
    access_level    ENUM('SUPER', 'MODERATOR', 'SUPPORT') NOT NULL DEFAULT 'MODERATOR',
    last_login_at   TIMESTAMP(3)    NULL,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (user_id),
    CONSTRAINT fk_admin_profiles_user
        FOREIGN KEY (user_id) REFERENCES users (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Extended profile for users with role ADMIN';

CREATE TABLE refresh_tokens (
    id              CHAR(36)        NOT NULL,
    user_id         CHAR(36)        NOT NULL,
    token_hash      CHAR(64)        NOT NULL COMMENT 'SHA-256 of raw refresh token',
    expires_at      TIMESTAMP(3)    NOT NULL,
    is_revoked      TINYINT(1)      NOT NULL DEFAULT 0,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT uk_refresh_tokens_hash UNIQUE (token_hash),
    INDEX idx_refresh_tokens_user (user_id),
    INDEX idx_refresh_tokens_expires (expires_at),
    CONSTRAINT fk_refresh_tokens_user
        FOREIGN KEY (user_id) REFERENCES users (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 2. CATALOG — CATEGORIES & PRODUCTS
-- -----------------------------------------------------------------------------

CREATE TABLE categories (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    parent_id       BIGINT UNSIGNED NULL COMMENT 'NULL = root category',
    name            VARCHAR(80)     NOT NULL,
    slug            VARCHAR(80)     NOT NULL,
    icon            VARCHAR(8)      NULL,
    color_hex       CHAR(7)         NULL COMMENT '#RRGGBB',
    bg_hex          CHAR(7)         NULL,
    sort_order      INT             NOT NULL DEFAULT 0,
    is_active       TINYINT(1)      NOT NULL DEFAULT 1,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT uk_categories_slug UNIQUE (slug),
    INDEX idx_categories_parent (parent_id),
    INDEX idx_categories_active_sort (is_active, sort_order),
    CONSTRAINT fk_categories_parent
        FOREIGN KEY (parent_id) REFERENCES categories (id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE products (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    seller_id       CHAR(36)        NOT NULL,
    category_id     BIGINT UNSIGNED NOT NULL,
    name            VARCHAR(200)    NOT NULL,
    slug            VARCHAR(220)    NULL,
    price           DECIMAL(12,2)   NOT NULL,
    unit            VARCHAR(30)     NOT NULL,
    aimag           VARCHAR(80)     NOT NULL COMMENT 'Denormalized for map/filter performance',
    emoji           VARCHAR(8)      NOT NULL DEFAULT '📦',
    story           TEXT            NULL,
    stock_quantity  INT UNSIGNED    NOT NULL DEFAULT 0,
    image_count     INT UNSIGNED    NOT NULL DEFAULT 1,
    is_new          TINYINT(1)      NOT NULL DEFAULT 0,
    is_organic      TINYINT(1)      NOT NULL DEFAULT 0,
    is_verified     TINYINT(1)      NOT NULL DEFAULT 0 COMMENT 'Product-level trust badge',
    is_active       TINYINT(1)      NOT NULL DEFAULT 1,
    rating_avg      DECIMAL(3,2)    NOT NULL DEFAULT 0.00,
    review_count    INT UNSIGNED    NOT NULL DEFAULT 0,
    seller_phone    VARCHAR(20)     NULL,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    INDEX idx_products_seller (seller_id),
    INDEX idx_products_category (category_id),
    INDEX idx_products_aimag_active (aimag, is_active),
    INDEX idx_products_price (price),
    INDEX idx_products_rating (rating_avg),
    INDEX idx_products_created (created_at),
    FULLTEXT INDEX ft_products_search (name, story),
    CONSTRAINT fk_products_seller
        FOREIGN KEY (seller_id) REFERENCES users (id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_products_category
        FOREIGN KEY (category_id) REFERENCES categories (id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_products_price CHECK (price > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE product_images (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    product_id      BIGINT UNSIGNED NOT NULL,
    image_url       VARCHAR(500)    NOT NULL,
    sort_order      INT             NOT NULL DEFAULT 0,
    is_primary      TINYINT(1)      NOT NULL DEFAULT 0,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    INDEX idx_product_images_product (product_id, sort_order),
    CONSTRAINT fk_product_images_product
        FOREIGN KEY (product_id) REFERENCES products (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 3. CART & WISHLIST
-- -----------------------------------------------------------------------------

CREATE TABLE carts (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         CHAR(36)        NOT NULL,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT uk_carts_user UNIQUE (user_id),
    CONSTRAINT fk_carts_user
        FOREIGN KEY (user_id) REFERENCES users (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE cart_items (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    cart_id         BIGINT UNSIGNED NOT NULL,
    product_id      BIGINT UNSIGNED NOT NULL,
    quantity        INT UNSIGNED    NOT NULL DEFAULT 1,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT uk_cart_items_cart_product UNIQUE (cart_id, product_id),
    INDEX idx_cart_items_product (product_id),
    CONSTRAINT fk_cart_items_cart
        FOREIGN KEY (cart_id) REFERENCES carts (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_cart_items_product
        FOREIGN KEY (product_id) REFERENCES products (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_cart_items_qty CHECK (quantity >= 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE wishlist_items (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         CHAR(36)        NOT NULL,
    product_id      BIGINT UNSIGNED NOT NULL,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT uk_wishlist_user_product UNIQUE (user_id, product_id),
    INDEX idx_wishlist_product (product_id),
    CONSTRAINT fk_wishlist_user
        FOREIGN KEY (user_id) REFERENCES users (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_wishlist_product
        FOREIGN KEY (product_id) REFERENCES products (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 4. ORDERS, PAYMENTS & DELIVERY
-- -----------------------------------------------------------------------------

CREATE TABLE orders (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    order_number        VARCHAR(24)     NOT NULL,
    buyer_id            CHAR(36)        NOT NULL,
    seller_id           CHAR(36)        NOT NULL,
    status              ENUM(
                            'БАТАЛГААЖСАН',
                            'БЭЛТГЭЖ_БАЙНА',
                            'ХҮРГЭЛТЭНД',
                            'ХҮРГЭГДСЭН',
                            'ЦУЦЛАСАН'
                        ) NOT NULL DEFAULT 'БАТАЛГААЖСАН',
    total_amount        DECIMAL(12,2)   NOT NULL,
    currency            CHAR(3)         NOT NULL DEFAULT 'MNT',
    payment_method      ENUM('CARD', 'QPAY', 'SOCIALPAY', 'CASH') NOT NULL,
    buyer_note          VARCHAR(500)    NULL,
    cancelled_reason    VARCHAR(255)    NULL,
    created_at          TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at          TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT uk_orders_number UNIQUE (order_number),
    INDEX idx_orders_buyer (buyer_id, created_at),
    INDEX idx_orders_seller (seller_id, status, created_at),
    INDEX idx_orders_status (status),
    CONSTRAINT fk_orders_buyer
        FOREIGN KEY (buyer_id) REFERENCES users (id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_orders_seller
        FOREIGN KEY (seller_id) REFERENCES users (id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_orders_total CHECK (total_amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE order_items (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    order_id        BIGINT UNSIGNED NOT NULL,
    product_id      BIGINT UNSIGNED NULL COMMENT 'Nullable if product later removed',
    product_name    VARCHAR(200)    NOT NULL COMMENT 'Snapshot at order time',
    product_emoji   VARCHAR(8)      NOT NULL,
    quantity        INT UNSIGNED    NOT NULL,
    unit_price      DECIMAL(12,2)   NOT NULL,
    subtotal        DECIMAL(12,2)   NOT NULL,
    PRIMARY KEY (id),
    INDEX idx_order_items_order (order_id),
    INDEX idx_order_items_product (product_id),
    CONSTRAINT fk_order_items_order
        FOREIGN KEY (order_id) REFERENCES orders (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_order_items_product
        FOREIGN KEY (product_id) REFERENCES products (id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT chk_order_items_qty CHECK (quantity >= 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE delivery_details (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    order_id        BIGINT UNSIGNED NOT NULL,
    recipient_name  VARCHAR(120)    NULL,
    phone           VARCHAR(20)     NOT NULL,
    aimag           VARCHAR(80)     NOT NULL,
    district        VARCHAR(80)     NULL,
    address_line    VARCHAR(300)    NOT NULL,
    delivery_note   VARCHAR(500)    NULL,
    estimated_at    TIMESTAMP(3)    NULL,
    delivered_at    TIMESTAMP(3)    NULL,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT uk_delivery_details_order UNIQUE (order_id),
    CONSTRAINT fk_delivery_details_order
        FOREIGN KEY (order_id) REFERENCES orders (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE order_status_history (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    order_id        BIGINT UNSIGNED NOT NULL,
    status          ENUM(
                        'БАТАЛГААЖСАН',
                        'БЭЛТГЭЖ_БАЙНА',
                        'ХҮРГЭЛТЭНД',
                        'ХҮРГЭГДСЭН',
                        'ЦУЦЛАСАН'
                    ) NOT NULL,
    label           VARCHAR(100)    NOT NULL COMMENT 'Display label for UI tracking step',
    is_done         TINYINT(1)      NOT NULL DEFAULT 1,
    note            VARCHAR(255)    NULL,
    changed_by      CHAR(36)        NULL COMMENT 'User who triggered change',
    event_at        TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    INDEX idx_order_status_history_order (order_id, event_at),
    CONSTRAINT fk_order_status_history_order
        FOREIGN KEY (order_id) REFERENCES orders (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_order_status_history_user
        FOREIGN KEY (changed_by) REFERENCES users (id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Delivery/order tracking timeline for buyer UI';

CREATE TABLE payments (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    order_id            BIGINT UNSIGNED NOT NULL,
    payment_method      ENUM('CARD', 'QPAY', 'SOCIALPAY', 'CASH') NOT NULL,
    status              ENUM(
                            'PENDING',
                            'PROCESSING',
                            'COMPLETED',
                            'FAILED',
                            'REFUNDED',
                            'CANCELLED'
                        ) NOT NULL DEFAULT 'PENDING',
    amount              DECIMAL(12,2)   NOT NULL,
    currency            CHAR(3)         NOT NULL DEFAULT 'MNT',
    transaction_ref     VARCHAR(100)    NULL COMMENT 'Gateway / QPay reference',
    gateway_response    JSON            NULL,
    paid_at             TIMESTAMP(3)    NULL,
    failed_at           TIMESTAMP(3)    NULL,
    created_at          TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at          TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    INDEX idx_payments_order (order_id),
    INDEX idx_payments_status (status),
    INDEX idx_payments_transaction (transaction_ref),
    CONSTRAINT fk_payments_order
        FOREIGN KEY (order_id) REFERENCES orders (id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_payments_amount CHECK (amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 5. REVIEWS
-- -----------------------------------------------------------------------------

CREATE TABLE reviews (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    product_id      BIGINT UNSIGNED NOT NULL,
    buyer_id        CHAR(36)        NOT NULL,
    rating          TINYINT UNSIGNED NOT NULL,
    comment         TEXT            NOT NULL,
    is_visible      TINYINT(1)      NOT NULL DEFAULT 1,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT uk_reviews_product_buyer UNIQUE (product_id, buyer_id),
    INDEX idx_reviews_product (product_id, created_at),
    INDEX idx_reviews_buyer (buyer_id),
    CONSTRAINT fk_reviews_product
        FOREIGN KEY (product_id) REFERENCES products (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_buyer
        FOREIGN KEY (buyer_id) REFERENCES users (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_reviews_rating CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 6. MESSAGES (CHAT)
-- -----------------------------------------------------------------------------

CREATE TABLE messages (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    sender_id       CHAR(36)        NOT NULL,
    receiver_id     CHAR(36)        NOT NULL,
    product_id      BIGINT UNSIGNED NULL COMMENT 'Optional product context',
    content         TEXT            NOT NULL,
    is_read         TINYINT(1)      NOT NULL DEFAULT 0,
    read_at         TIMESTAMP(3)    NULL,
    sent_at         TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    INDEX idx_messages_conversation (sender_id, receiver_id, sent_at),
    INDEX idx_messages_receiver_unread (receiver_id, is_read),
    INDEX idx_messages_product (product_id),
    CONSTRAINT fk_messages_sender
        FOREIGN KEY (sender_id) REFERENCES users (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_messages_receiver
        FOREIGN KEY (receiver_id) REFERENCES users (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_messages_product
        FOREIGN KEY (product_id) REFERENCES products (id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT chk_messages_not_self CHECK (sender_id <> receiver_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 7. NOTIFICATIONS
-- -----------------------------------------------------------------------------

CREATE TABLE notifications (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         CHAR(36)        NOT NULL,
    type            ENUM('ORDER', 'CHAT', 'PROMO', 'SYSTEM') NOT NULL,
    icon            VARCHAR(8)      NOT NULL,
    title           VARCHAR(200)    NOT NULL,
    body            TEXT            NOT NULL,
    reference_type  VARCHAR(50)     NULL COMMENT 'e.g. order, product, message',
    reference_id    VARCHAR(36)     NULL,
    is_read         TINYINT(1)      NOT NULL DEFAULT 0,
    read_at         TIMESTAMP(3)    NULL,
    created_at      TIMESTAMP(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    INDEX idx_notifications_user_read (user_id, is_read, created_at),
    INDEX idx_notifications_type (type),
    CONSTRAINT fk_notifications_user
        FOREIGN KEY (user_id) REFERENCES users (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 8. SEED — CATEGORIES (matches frontend CATEGORIES)
-- -----------------------------------------------------------------------------

INSERT INTO categories (name, slug, icon, color_hex, bg_hex, sort_order) VALUES
('Мах',             'mah',              '🥩', '#dc2626', '#fef2f2', 1),
('Цагаан идээ',     'tsagaan-idee',     '🥛', '#06b6d4', '#eff6ff', 2),
('Ноос ноолуур',    'noos-nooluur',     '🧶', '#7c3aed', '#f5f3ff', 3),
('Гар урлал',       'gar-urallag',      '🎨', '#b45309', '#fffbeb', 4),
('Тариалан',        'tarialan',         '🌾', '#10b981', '#f0fdf4', 5),
('Байгалийн бүт.',  'baigalijn-but',    '🍯', '#ca8a04', '#fefce8', 6),
('Загас',           'zagas',            '🐟', '#0891b2', '#ecfeff', 7),
('Эмийн ургамал',   'emiin-urgamal',    '🌿', '#059669', '#ecfdf5', 8);

SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================================
-- End of schema
-- =============================================================================
