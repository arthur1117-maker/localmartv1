# LocalMart Connected — MySQL Database Design

Production schema for the marketplace platform. Aligns with the Spring Boot JPA layer while adding normalized **categories**, **payments**, **delivery tracking**, and **role profiles** (seller/admin).

---

## 1. Design principles

| Principle | Application |
|-----------|-------------|
| **3NF normalization** | Categories, payments, and delivery events are separate tables — no duplicated category names or payment state on `orders` alone |
| **Single user identity** | One `users` row per person; seller/admin attributes live in profile tables (1:1) |
| **Role via ENUM** | `users.role` = `BUYER` \| `SELLER` \| `ADMIN` — enforced with profile FK checks in application layer |
| **Soft business rules** | Sellers must have `seller_profiles`; admins optional `admin_profiles` |
| **Audit timestamps** | `created_at`, `updated_at` on mutable entities; history tables are insert-only |
| **Mongolian order flow** | Status ENUM matches frontend: `БАТАЛГААЖСАН` → `БЭЛТГЭЖ_БАЙНА` → `ХҮРГЭЛТЭНД` → `ХҮРГЭГДСЭН` / `ЦУЦЛАСАН` |
| **InnoDB + utf8mb4** | FK constraints, row-level locking, full Unicode (Mongolian text) |

---

## 2. Entity Relationship Diagram

```mermaid
erDiagram
    users ||--o| seller_profiles : "is seller"
    users ||--o| admin_profiles : "is admin"
    users ||--o{ refresh_tokens : has
    users ||--o{ products : sells
    users ||--o{ orders : buys
    users ||--o{ orders : fulfills
    users ||--o{ reviews : writes
    users ||--o{ carts : owns
    users ||--o{ wishlist_items : saves
    users ||--o{ messages : sends
    users ||--o{ messages : receives
    users ||--o{ notifications : receives

    categories ||--o{ products : contains
    categories ||--o{ categories : parent

    products ||--o{ order_items : "ordered as"
    products ||--o{ cart_items : "in cart"
    products ||--o{ wishlist_items : wishlisted
    products ||--o{ reviews : reviewed
    products ||--o{ messages : "about"

    orders ||--|{ order_items : contains
    orders ||--o| payments : paid_by
    orders ||--o{ order_status_history : tracks
    orders ||--o| delivery_details : ships_to

    carts ||--|{ cart_items : contains

    users {
        char36 id PK
        varchar email UK
        enum role
        boolean active
    }

    seller_profiles {
        char36 user_id PK_FK
        varchar shop_name
        boolean verified
    }

    admin_profiles {
        char36 user_id PK_FK
        varchar department
    }

    categories {
        bigint id PK
        varchar slug UK
        bigint parent_id FK
    }

    products {
        bigint id PK
        char36 seller_id FK
        bigint category_id FK
    }

    orders {
        bigint id PK
        varchar order_number UK
        char36 buyer_id FK
        char36 seller_id FK
        enum status
    }

    payments {
        bigint id PK
        bigint order_id FK
        enum status
    }

    order_status_history {
        bigint id PK
        bigint order_id FK
        enum status
    }

    delivery_details {
        bigint id PK
        bigint order_id FK
    }
```

---

## 3. Table groups & relationships

### 3.1 Identity & access

| Table | Purpose | Relationships |
|-------|---------|---------------|
| **users** | Core account (all roles) | 1 → 0..1 `seller_profiles`, 0..1 `admin_profiles` |
| **seller_profiles** | Shop/business data for sellers | `user_id` → `users.id` (PK+FK, CASCADE) |
| **admin_profiles** | Admin metadata | `user_id` → `users.id` (PK+FK, CASCADE) |
| **refresh_tokens** | JWT refresh rotation | `user_id` → `users.id` (CASCADE delete) |

**Rule:** A user with `role = SELLER` should have exactly one `seller_profiles` row. Same pattern for `ADMIN` / `admin_profiles`.

---

### 3.2 Catalog

| Table | Purpose | Relationships |
|-------|---------|---------------|
| **categories** | Product taxonomy (supports tree via `parent_id`) | Self-FK `parent_id` → `categories.id` |
| **products** | Listings | `seller_id` → `users`, `category_id` → `categories` |
| **product_images** | Optional media (future CDN URLs) | `product_id` → `products` (CASCADE) |

**Migration note:** Current JPA uses `products.category` as VARCHAR; production schema uses `category_id` FK. Map category labels in seed/migration script.

---

### 3.3 Commerce

| Table | Purpose | Relationships |
|-------|---------|---------------|
| **carts** | One active cart per buyer | `user_id` → `users` (UK — one cart per user) |
| **cart_items** | Lines in cart | `cart_id` → `carts`, `product_id` → `products` |
| **wishlist_items** | Saved products | `user_id` + `product_id` (composite UK) |
| **orders** | Purchase header (per seller per checkout) | `buyer_id`, `seller_id` → `users` |
| **order_items** | Snapshot of line at purchase time | `order_id` → `orders`, `product_id` → `products` (SET NULL if product deleted) |
| **payments** | Payment attempt/settlement | `order_id` → `orders` (1:1 or 1:N if retries) |
| **delivery_details** | Shipping address snapshot | `order_id` → `orders` (1:1) |
| **order_status_history** | Tracking timeline (UI steps) | `order_id` → `orders` |

---

### 3.4 Engagement

| Table | Purpose | Relationships |
|-------|---------|---------------|
| **reviews** | Product ratings | `product_id`, `buyer_id` (UK pair — one review per buyer per product) |
| **messages** | Buyer ↔ seller chat | `sender_id`, `receiver_id` → `users`; optional `product_id` |
| **notifications** | In-app alerts | `user_id` → `users` |

---

## 4. Cardinality summary

```
users (1) ──< (N) products          [seller lists many products]
users (1) ──< (N) orders           [as buyer]
users (1) ──< (N) orders           [as seller]
users (1) ─── (1) carts            [one cart per buyer]
carts (1) ──< (N) cart_items
users (1) ──< (N) wishlist_items
products (1) ──< (N) order_items
orders (1) ──< (N) order_items
orders (1) ─── (1) delivery_details
orders (1) ──< (N) order_status_history
orders (1) ─── (1) payments        [primary payment; retries = extra rows]
categories (1) ──< (N) products
categories (1) ──< (N) categories  [parent/child tree]
```

---

## 5. ENUM definitions

| Enum | Values | Used in |
|------|--------|---------|
| `user_role` | `BUYER`, `SELLER`, `ADMIN` | `users.role` |
| `order_status` | `БАТАЛГААЖСАН`, `БЭЛТГЭЖ_БАЙНА`, `ХҮРГЭЛТЭНД`, `ХҮРГЭГДСЭН`, `ЦУЦЛАСАН` | `orders.status`, `order_status_history.status` |
| `payment_method` | `CARD`, `QPAY`, `SOCIALPAY`, `CASH` | `payments.payment_method`, `orders.payment_method` |
| `payment_status` | `PENDING`, `PROCESSING`, `COMPLETED`, `FAILED`, `REFUNDED`, `CANCELLED` | `payments.status` |
| `notification_type` | `ORDER`, `CHAT`, `PROMO`, `SYSTEM` | `notifications.type` |

---

## 6. Index strategy

| Pattern | Example indexes |
|---------|-----------------|
| FK columns | All `*_id` columns indexed |
| Lookup | `users.email` (UNIQUE), `orders.order_number` (UNIQUE) |
| Listing filters | `products(category_id, active)`, `products(aimag, active)` |
| Feed / inbox | `notifications(user_id, is_read, created_at DESC)` |
| Chat | `messages(sender_id, receiver_id, sent_at)` |
| Analytics | `orders(seller_id, status, created_at)` |

---

## 7. JPA ↔ SQL mapping (current backend)

| JPA entity | SQL table | Notes |
|------------|-----------|-------|
| `User` | `users` | Unchanged |
| — | `seller_profiles`, `admin_profiles` | **New** — add entities later |
| `Product` | `products` | Add `category_id`; keep `aimag` as denormalized filter column optional |
| `Order` | `orders` | Unchanged core |
| `OrderItem` | `order_items` | Unchanged |
| `CartItem` | `cart_items` | Wrap with `carts` table |
| `WishlistItem` | `wishlist_items` | Unchanged |
| `ChatMessage` | `messages` | Rename table in migration |
| `Notification` | `notifications` | Unchanged |
| `Review` | `reviews` | Unchanged |
| — | `payments`, `delivery_details`, `order_status_history` | **New** |

---

## 8. Files

| File | Description |
|------|-------------|
| `schema.sql` | Full DDL — CREATE DATABASE, tables, FKs, indexes, seed categories |
| `DATABASE_SCHEMA.md` | This document |

**Apply schema:**

```bash
mysql -u root -p < database/schema.sql
```

Set `SPRING_PROFILES_ACTIVE=mysql` and run the Spring Boot app (JPA `ddl-auto=validate` recommended after migration).
