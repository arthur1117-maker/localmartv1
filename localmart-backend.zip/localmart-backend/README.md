# LocalMart Connected — Backend API

Production-style Spring Boot 3 marketplace API for the **LocalMart Connected** Next.js frontend.

## Stack

- Java 17
- Spring Boot 3.2
- Spring Security + JWT (access + refresh)
- Spring Data JPA
- MySQL (production) / H2 (local dev default)
- Lombok, Bean Validation

## Quick start (dev — H2 in-memory)

### Prerequisites

Install **JDK 17+** and **Maven 3.9+**, then:

```bash
cd localmart-backend
mvn spring-boot:run
```

API base: `http://localhost:8080/api`  
H2 console: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:localmart`)

### Seed accounts

| Email | Password | Role |
|-------|----------|------|
| admin@localmart.mn | Admin123! | admin |
| seller@test.mn | Seller123! | seller |
| seller2@test.mn | Seller123! | seller |
| buyer@test.mn | Buyer123! | user (buyer) |

## Database (MySQL)

Full production schema with ERD, relationships, and DDL:

- **Design doc:** [database/DATABASE_SCHEMA.md](./database/DATABASE_SCHEMA.md)
- **SQL script:** [database/schema.sql](./database/schema.sql)

```bash
mysql -u root -p < database/schema.sql
```

Tables: `users`, `seller_profiles`, `admin_profiles`, `categories`, `products`, `orders`, `order_items`, `payments`, `delivery_details`, `order_status_history`, `carts`, `wishlist_items`, `messages`, `notifications`, `reviews`, and more.

## MySQL (production profile)

```bash
# Or apply schema.sql first, then:

# Run with MySQL profile
set SPRING_PROFILES_ACTIVE=mysql
set DB_USER=root
set DB_PASSWORD=yourpassword
set JWT_SECRET=your-256-bit-secret-key-here

mvn spring-boot:run
```

## Connect frontend

In the Next.js project root, create `.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8080/api
```

Then `npm run dev` — login, explore, seller dashboard, orders, chat, and notifications use the live API.

## Authentication (JWT)

See [docs/AUTH.md](./docs/AUTH.md) for roles, tokens, logout, and protected routes.

| Endpoint | Description |
|----------|-------------|
| `POST /api/auth/login` | Login |
| `POST /api/auth/register` | Register |
| `POST /api/auth/refresh` | Refresh access token |
| `POST /api/auth/logout` | Revoke refresh token |
| `POST /api/auth/logout-all` | Sign out all devices (Bearer required) |

## API modules

| Prefix | Description |
|--------|-------------|
| `/api/auth` | Login, register, refresh |
| `/api/users` | Current user profile |
| `/api/products` | Search, CRUD (seller) |
| `/api/orders` | Checkout, tracking, seller fulfillment |
| `/api/reviews` | Product reviews |
| `/api/chat` | Buyer–seller messaging |
| `/api/notifications` | In-app notifications |
| `/api/seller` | Dashboard analytics |
| `/api/admin` | User/product moderation |
| `/api/cart` | Server-side cart (optional) |
| `/api/wishlist` | Saved products (optional) |

Full design: see [ARCHITECTURE.md](./ARCHITECTURE.md).  
**Complete folder tree:** see [STRUCTURE.md](./STRUCTURE.md).

## Enterprise packages

| Package | Purpose |
|---------|---------|
| `common.response` | `ApiResponse<T>` wrapper + `ApiResponseBodyAdvice` |
| `common.pagination` | `PageResponse`, `PageQuery`, `PaginationUtils` |
| `common.exception` | `ApiException`, `GlobalExceptionHandler` |
| `mapper` | Entity ↔ DTO mapping (no logic in DTOs) |
| `dto.request` / `dto.response` | Validated API contracts |
| `service` + `service.impl` | Interface + implementation |
| `validation` | Custom `@ValidRole` constraint |

## Build

```bash
mvn clean package
java -jar target/localmart-backend-1.0.0.jar
```
