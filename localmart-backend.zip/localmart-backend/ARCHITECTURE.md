# LocalMart Connected — Backend Architecture

## 1. Frontend Analysis Summary

### Stack
- **Next.js 16** (App Router), React 19, TypeScript, Tailwind
- **State**: React Context (Auth, Cart, Wishlist, Chat, Notifications, Theme)
- **API client**: `src/lib/api/index.ts` → `http://localhost:8080/api`
- **Mock data**: `src/lib/data` (products, categories, aimags) — replaced at runtime by API where wired

### Views & Roles
| Tab / View | Role | Backend dependency |
|------------|------|-------------------|
| Home / Explore | Public + buyer | Product search, pagination, filters |
| Product modal | All | Product detail, reviews, chat, cart (local) |
| Seller dashboard | Seller | CRUD products, seller orders, stats |
| Orders | Buyer | Create order, my orders, tracking |
| Admin panel | Admin | Users, product moderation, orders (partial mock today) |
| Auth | All | Login, register, JWT refresh, `/users/me` |
| Chat | Logged-in | Send, conversation, unread, mark read |
| Notifications | Logged-in | List, unread count, mark read |

### Frontend API Contract (must match)
All paths are prefixed with `/api` (see `API_BASE`).

| Module | Endpoints |
|--------|-----------|
| Auth | `POST /auth/login`, `/auth/register`, `/auth/refresh` |
| User | `GET /users/me` |
| Products | `GET /products/search`, `GET /products/{id}`, `GET /products/me`, `POST /products`, `PUT /products/{id}`, `DELETE /products/{id}` |
| Orders | `POST /orders`, `GET /orders/my`, `GET /orders/{orderNumber}`, `GET /orders/seller`, `PATCH /orders/{orderNumber}/status` |
| Reviews | `GET /reviews/product/{id}`, `POST /reviews` |
| Chat | `POST /chat/send`, `GET /chat/conversation/{partnerId}`, `GET /chat/unread`, `PATCH /chat/read/{senderId}` |
| Notifications | `GET /notifications`, `GET /notifications/unread`, `PATCH /notifications/{id}/read`, `PATCH /notifications/read-all` |
| Seller | `GET /seller/stats` |
| Admin | `GET /admin/users`, `PATCH /admin/users/{id}/toggle-active`, `PATCH /admin/users/{id}/verify`, `PATCH /admin/products/{id}/toggle-active` |

### Extended APIs (production; frontend can adopt)
| Module | Endpoints |
|--------|-----------|
| Cart | `GET /cart`, `POST /cart/items`, `PUT /cart/items/{productId}`, `DELETE /cart/items/{productId}`, `DELETE /cart` |
| Wishlist | `GET /wishlist`, `POST /wishlist/{productId}`, `DELETE /wishlist/{productId}` |
| Admin analytics | `GET /admin/analytics/overview` |

---

## 2. Layered Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Controllers (REST, validation, RBAC via @PreAuthorize)      │
├─────────────────────────────────────────────────────────────┤
│  Services (business logic, transactions, notifications)      │
├─────────────────────────────────────────────────────────────┤
│  Repositories (Spring Data JPA, specifications for search)   │
├─────────────────────────────────────────────────────────────┤
│  Entities + Enums                                            │
└─────────────────────────────────────────────────────────────┘
         │                    │
    Security (JWT)      Exception Handler
    Config (CORS, JPA)  DTOs (API boundary)
```

**Packages**: `com.localmart.{config,security,entity,enums,repository,dto,service,controller,exception}`

---

## 3. Database Schema (MySQL)

### `users`
| Column | Type | Notes |
|--------|------|-------|
| id | CHAR(36) PK | UUID |
| name | VARCHAR(120) | |
| email | VARCHAR(180) UNIQUE | |
| password_hash | VARCHAR(255) | BCrypt |
| role | ENUM BUYER, SELLER, ADMIN | |
| phone | VARCHAR(20) | |
| aimag | VARCHAR(80) | Mongolia province |
| avatar | VARCHAR(16) | Emoji default |
| verified | BOOLEAN | Seller verification |
| active | BOOLEAN | Admin can disable |
| created_at | TIMESTAMP | |

### `refresh_tokens`
| id | user_id FK | token_hash | expires_at | revoked |

### `products`
| id BIGINT PK | seller_id FK | name, price DECIMAL | unit, category, aimag, emoji |
| story TEXT | stock INT | image_count | is_new, is_organic, verified, active |
| rating_avg DECIMAL(3,2) | review_count INT | created_at |

### `orders`
| id BIGINT | order_number VARCHAR UNIQUE | buyer_id, seller_id FK |
| status ENUM (Mongolian labels stored as string) | total_amount | delivery_address |
| buyer_phone | payment_method | created_at, updated_at |

### `order_items`
| order_id FK | product_id FK | product_name, emoji | quantity | unit_price | subtotal |

### `reviews`
| product_id, buyer_id | rating 1-5 | comment | created_at |

### `chat_messages`
| sender_id, receiver_id | content | product_id nullable | is_read | sent_at |

### `notifications`
| user_id | type | icon | title | body | is_read | created_at |

### `cart_items`
| user_id, product_id UNIQUE | quantity |

### `wishlist_items`
| user_id, product_id UNIQUE | created_at |

---

## 4. Entity Relationships

```mermaid
erDiagram
    USER ||--o{ PRODUCT : sells
    USER ||--o{ ORDER : buys
    USER ||--o{ ORDER : fulfills
    USER ||--o{ REVIEW : writes
    USER ||--o{ CHAT_MESSAGE : sends
    USER ||--o{ NOTIFICATION : receives
    USER ||--o{ CART_ITEM : owns
    USER ||--o{ WISHLIST_ITEM : owns
    PRODUCT ||--o{ ORDER_ITEM : contains
    PRODUCT ||--o{ REVIEW : has
    ORDER ||--|{ ORDER_ITEM : has
```

---

## 5. Security Model

- **JWT access token** (15 min) + **refresh token** (7 days, stored hashed)
- `JwtAuthenticationFilter` → `SecurityContext`
- `@PreAuthorize("hasRole('SELLER')")` etc.
- Public: product search, product by id, auth register/login
- Buyer: orders (create/my), reviews, cart, wishlist, chat, notifications
- Seller: product CRUD (own), seller orders, stats
- Admin: user moderation, all products toggle, analytics

---

## 6. Order Status Flow

```
БАТАЛГААЖСАН → БЭЛТГЭЖ_БАЙНА → ХҮРГЭЛТЭНД → ХҮРГЭГДСЭН
                    ↘ ЦУЦЛАСАН (any stage by buyer/seller/admin rules)
```

---

## 7. Seed Accounts (dev)

| Email | Password | Role |
|-------|----------|------|
| admin@localmart.mn | Admin123! | ADMIN |
| seller@test.mn | Seller123! | SELLER |
| buyer@test.mn | Buyer123! | BUYER |
