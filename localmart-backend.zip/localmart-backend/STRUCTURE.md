# LocalMart Backend — Enterprise Folder Structure

```
localmart-backend/
├── pom.xml
├── README.md
├── ARCHITECTURE.md
├── STRUCTURE.md
└── src/
    ├── main/
    │   ├── java/com/localmart/
    │   │   ├── LocalMartApplication.java
    │   │   │
    │   │   ├── common/                          # Cross-cutting shared code
    │   │   │   ├── annotation/
    │   │   │   │   └── DirectResponse.java      # Skip ApiResponse wrapper (frontend contract)
    │   │   │   ├── constants/
    │   │   │   │   └── AppConstants.java
    │   │   │   ├── exception/
    │   │   │   │   ├── ApiException.java
    │   │   │   │   ├── ErrorResponse.java
    │   │   │   │   └── GlobalExceptionHandler.java
    │   │   │   ├── pagination/
    │   │   │   │   ├── PageQuery.java           # Validated page/size/sort input
    │   │   │   │   ├── PageResponse.java        # Spring Data page → API shape
    │   │   │   │   └── PaginationUtils.java
    │   │   │   ├── response/
    │   │   │   │   ├── ApiResponse.java         # Standard success wrapper
    │   │   │   │   ├── ApiResponseFactory.java
    │   │   │   │   └── ApiResponseBodyAdvice.java
    │   │   │   └── util/
    │   │   │       └── HashUtils.java
    │   │   │
    │   │   ├── config/                          # Spring @Configuration
    │   │   │   ├── CorsConfig.java
    │   │   │   ├── DataSeeder.java
    │   │   │   ├── JpaConfig.java
    │   │   │   ├── SecurityConfig.java
    │   │   │   └── WebConfig.java
    │   │   │
    │   │   ├── controller/                      # REST layer (thin)
    │   │   │   ├── AdminController.java
    │   │   │   ├── AuthController.java
    │   │   │   ├── CartController.java
    │   │   │   ├── ChatController.java
    │   │   │   ├── NotificationController.java
    │   │   │   ├── OrderController.java
    │   │   │   ├── ProductController.java
    │   │   │   ├── ReviewController.java
    │   │   │   ├── SellerController.java
    │   │   │   ├── UserController.java
    │   │   │   └── WishlistController.java
    │   │   │
    │   │   ├── dto/
    │   │   │   ├── request/                     # Inbound payloads (@Valid)
    │   │   │   │   ├── auth/
    │   │   │   │   ├── cart/
    │   │   │   │   ├── chat/
    │   │   │   │   ├── order/
    │   │   │   │   ├── product/
    │   │   │   │   └── review/
    │   │   │   └── response/                    # Outbound payloads
    │   │   │       ├── admin/
    │   │   │       ├── auth/
    │   │   │       ├── cart/
    │   │   │       ├── chat/
    │   │   │       ├── notification/
    │   │   │       ├── order/
    │   │   │       ├── product/
    │   │   │       ├── review/
    │   │   │       ├── seller/
    │   │   │       └── user/
    │   │   │
    │   │   ├── entity/                          # JPA domain models
    │   │   │   ├── BaseEntity.java
    │   │   │   ├── CartItem.java
    │   │   │   ├── ChatMessage.java
    │   │   │   ├── Notification.java
    │   │   │   ├── Order.java
    │   │   │   ├── OrderItem.java
    │   │   │   ├── Product.java
    │   │   │   ├── RefreshToken.java
    │   │   │   ├── Review.java
    │   │   │   ├── User.java
    │   │   │   └── WishlistItem.java
    │   │   │
    │   │   ├── enums/
    │   │   │   ├── NotificationType.java
    │   │   │   ├── OrderStatus.java
    │   │   │   └── Role.java
    │   │   │
    │   │   ├── mapper/                          # Entity ↔ DTO mapping
    │   │   │   ├── CartMapper.java
    │   │   │   ├── ChatMapper.java
    │   │   │   ├── NotificationMapper.java
    │   │   │   ├── OrderMapper.java
    │   │   │   ├── ProductMapper.java
    │   │   │   ├── ReviewMapper.java
    │   │   │   ├── SellerMapper.java
    │   │   │   └── UserMapper.java
    │   │   │
    │   │   ├── repository/                      # Spring Data JPA
    │   │   │   ├── CartItemRepository.java
    │   │   │   ├── ChatMessageRepository.java
    │   │   │   ├── NotificationRepository.java
    │   │   │   ├── OrderRepository.java
    │   │   │   ├── ProductRepository.java
    │   │   │   ├── RefreshTokenRepository.java
    │   │   │   ├── ReviewRepository.java
    │   │   │   ├── UserRepository.java
    │   │   │   ├── WishlistItemRepository.java
    │   │   │   └── specification/
    │   │   │       └── ProductSpecifications.java
    │   │   │
    │   │   ├── security/                        # JWT + UserDetails
    │   │   │   ├── JwtAuthenticationFilter.java
    │   │   │   ├── JwtProperties.java
    │   │   │   ├── JwtService.java
    │   │   │   ├── LocalMartUserDetails.java
    │   │   │   ├── LocalMartUserDetailsService.java
    │   │   │   └── SecurityUtils.java
    │   │   │
    │   │   ├── service/                         # Business contracts
    │   │   │   ├── AdminService.java
    │   │   │   ├── AuthService.java
    │   │   │   ├── CartService.java
    │   │   │   ├── ChatService.java
    │   │   │   ├── NotificationService.java
    │   │   │   ├── OrderService.java
    │   │   │   ├── ProductService.java
    │   │   │   ├── ReviewService.java
    │   │   │   ├── SellerAnalyticsService.java
    │   │   │   ├── WishlistService.java
    │   │   │   ├── support/
    │   │   │   │   └── NotificationPublisher.java
    │   │   │   └── impl/
    │   │   │       ├── AdminServiceImpl.java
    │   │   │       ├── AuthServiceImpl.java
    │   │   │       ├── CartServiceImpl.java
    │   │   │       ├── ChatServiceImpl.java
    │   │   │       ├── NotificationServiceImpl.java
    │   │   │       ├── OrderServiceImpl.java
    │   │   │       ├── ProductServiceImpl.java
    │   │   │       ├── ReviewServiceImpl.java
    │   │   │       ├── SellerAnalyticsServiceImpl.java
    │   │   │       └── WishlistServiceImpl.java
    │   │   │
    │   │   └── validation/                      # Custom Bean Validation
    │   │       ├── ValidRole.java
    │   │       └── RoleValidator.java
    │   │
    │   └── resources/
    │       ├── application.yml
    │       └── application-mysql.yml
    │
    └── test/java/com/localmart/
        └── LocalMartApplicationTests.java
```

## Layer responsibilities

| Layer | Responsibility |
|-------|----------------|
| **controller** | HTTP mapping, `@Valid`, security annotations, delegates to services |
| **service** | Business rules, transactions, orchestration |
| **repository** | Persistence queries |
| **mapper** | Pure mapping between entity and DTO |
| **dto** | API contracts (no JPA annotations) |
| **entity** | Database mapping |
| **common** | Wrappers, pagination, errors, shared utilities |
| **security** | Authentication & authorization |
| **validation** | Custom constraint validators |

## Response conventions

- **`ApiResponse<T>`** — default wrapper: `{ success, message, data, timestamp }`
- **`@DirectResponse`** — returns raw `T` for Next.js frontend compatibility (`/api/*`)
- **`PageResponse<T>`** — pagination: `{ content, totalElements, totalPages, number, size }`
